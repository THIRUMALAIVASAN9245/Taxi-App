﻿namespace Booking.Api.Infrastructure
{
    using Booking.Domain.Dto;

    public interface IIdentityService
    {
        IdentityModel GetIdentity();
    }
}
