﻿namespace Booking.Api.Infrastructure.Filters
{
    using System;
    using System.Net;
    using Booking.Domain.Exceptions;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Global filter, which provide cross cutting concern of handling exceptions
    /// Return appropriate status code and http response according to exceptions has been thrown
    /// </summary>
    public class HttpGlobalExceptionFilter : IExceptionFilter
    {
        private readonly IHostingEnvironment _env;
        private readonly ILogger<HttpGlobalExceptionFilter> _logger;

        public HttpGlobalExceptionFilter(IHostingEnvironment env, ILogger<HttpGlobalExceptionFilter> logger)
        {
            _env = env ?? throw new ArgumentNullException(nameof(env));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void OnException(ExceptionContext context)
        {
            var response = HandleException(context.Exception);

            context.Result = response.ObjectResult;
            context.HttpContext.Response.StatusCode = response.StatusCode;

            context.ExceptionHandled = true;
        }

        /// <summary>
        /// Handle exception, and return appropriate HttpResponse
        /// </summary>
        /// <param name="ex">Input Exception</param>
        /// <returns>HttpResponse</returns>
        private HttpResponse HandleException(Exception ex)
        {
            var response = new HttpResponse();

            if (ex.GetType() == typeof(NotFoundException))
            {
                response.ObjectResult = new NotFoundObjectResult(ex.Message);
                response.StatusCode = (int) HttpStatusCode.NotFound;
            }
            //by requirements we need to return bad request in other cases.
            else
            {
                _logger.LogCritical($"Server Error: {ex.Message}");
                response.StatusCode = (int) HttpStatusCode.BadRequest;
            }

            return response;
        }

        private class HttpResponse
        {
            public int StatusCode { get; set; }
            public ObjectResult ObjectResult { get; set; }
        }
    }
}
