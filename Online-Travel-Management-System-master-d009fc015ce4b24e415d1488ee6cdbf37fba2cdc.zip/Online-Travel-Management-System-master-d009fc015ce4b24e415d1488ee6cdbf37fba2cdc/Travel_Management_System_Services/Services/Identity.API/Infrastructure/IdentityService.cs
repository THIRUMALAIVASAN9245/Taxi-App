﻿namespace Booking.Api.Infrastructure
{
    using Booking.Domain.Dto;
    using Microsoft.AspNetCore.Http;
    using System;
    using System.Linq;

    public class IdentityService : IIdentityService
    {
        private IHttpContextAccessor _context;

        public IdentityService(IHttpContextAccessor context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public IdentityModel GetIdentity()
        {
            var authorizationHeader = this._context.HttpContext.User;

            if (authorizationHeader != null)
            {
                var userId = authorizationHeader.Claims
                    .Where(c => c.Type == "userId")
                    .FirstOrDefault();

                var roleId = authorizationHeader.Claims
                    .Where(c => c.Type == "roleId")
                    .FirstOrDefault();

                return new IdentityModel()
                {
                    RoleId = Convert.ToInt16(roleId.Value),
                    UserId = new Guid(userId.Value)
                };
            }

            throw new ArgumentNullException("UserIdentity");
        }
    }
}
