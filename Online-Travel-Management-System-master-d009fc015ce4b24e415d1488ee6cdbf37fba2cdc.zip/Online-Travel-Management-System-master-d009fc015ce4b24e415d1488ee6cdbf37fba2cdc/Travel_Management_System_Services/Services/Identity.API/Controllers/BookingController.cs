﻿namespace Booking.Api.Controllers
{
    using MediatR;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using Booking.Api.Infrastructure;
    using Booking.Domain.Dto;
    using Booking.Api.Queries.CreateBooking;
    using Booking.Api.Queries.UpdateBooking;
    using Booking.Api.Queries.GetBooking;

    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [EnableCors("CorsPolicy")]
    public class BookingController : Controller
    {
        private readonly IMediator mediatR;

        private readonly IIdentityService identityService;

        /// <summary>
        /// BookingController constructor
        /// </summary>
        /// <param name="mediatR"></param>
        /// <param name="identityService"></param>
        public BookingController(IMediator mediatR, IIdentityService identityService)
        {
            this.mediatR = mediatR;
            this.identityService = identityService;
        }

        /// <summary>
        /// Create new ride
        /// </summary>
        /// <param name="bookingRequest">Create new ride</param>
        /// <returns>Saved booking data object</returns>
        [HttpPost]
        [ProducesResponseType(201, Type = typeof(Booking))]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        public async Task<IActionResult> Post([FromBody]Booking bookingRequest)
        {
            var loginIdentity = identityService.GetIdentity();
            bookingRequest.CustomerId = loginIdentity.UserId.ToString();

            var response = await mediatR.Send(new CreateBookingRequest(bookingRequest));

            if (response == null)
            {
                return StatusCode(409, "Error Occurred While Creating a Ride"); ;
            }

            return Created("New Ride created", response);
        }

        /// <summary>
        /// Update booking detail
        /// </summary>
        /// <param name="bookingModel">Updated booking data object</param>
        /// <returns>Saved booking data object</returns>
        [HttpPut]
        [ProducesResponseType(200, Type = typeof(Booking))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> Put([FromBody]Booking bookingModel)
        {
            var response = await mediatR.Send(new UpdateBookingRequest(bookingModel));

            if (response == null)
            {
                return StatusCode(409, "Error Occurred While updating The booking");
            }

            return Ok(bookingModel);
        }

        /// <summary>
        /// Get Rides
        /// </summary>
        /// <returns>list of Ride</returns>
        [HttpGet, Route("GetBooking")]
        [ProducesResponseType(200, Type = typeof(BookingResponse))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetBooking(BookingRequest bookingRequest)
        {
            var loginIdentity = identityService.GetIdentity();
            bookingRequest.IdentityModel = loginIdentity;
            var response = await mediatR.Send(new GetBookingRequest(bookingRequest));

            if (response == null)
            {
                return NotFound("No ride found");
            }

            return Ok(response);
        }
    }
}