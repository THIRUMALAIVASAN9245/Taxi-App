﻿namespace Booking.Api.Queries.UpdateBooking
{
    using MediatR;
    using Booking.Domain.Dto;

    /// <summary>
    /// UpdateBookingRequest class
    /// </summary>
    public class UpdateBookingRequest : IRequest<Booking>
    {
        public Booking BookingModel { get; set; }

        ///<Summary>
        /// UpdateBookingRequest constructor
        ///</Summary>  
        ///<param name="bookingModel">bookingModel</param>
        public UpdateBookingRequest(Booking bookingModel)
        {
            this.BookingModel = bookingModel;
        }
    }
}
