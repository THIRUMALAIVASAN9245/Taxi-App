﻿namespace Booking.Api.Queries.GetBooking
{
    using AutoMapper;
    using MediatR;
    using Booking.Domain.Dto;
    using System.Threading.Tasks;
    using System.Threading;
    using System.Collections.Generic;
    using System.Linq;
    using Booking.Domain.Interfaces;
    using Booking.Domain.Aggregates.BookingInfo;
    using System;
    using Booking.Domain.Aggregates.ValueObjects;

    /// <summary>
    /// GetBookingById class
    /// </summary>
    public class GetBooking : IRequestHandler<GetBookingRequest, BookingResponse>
    {
        private IRepository repository;

        private IMapper mapper;

        /// <summary>
        /// GetBookingById constructor
        /// </summary>
        /// <param name="repository"></param>
        /// <param name="mapper"></param>
        public GetBooking(IRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Handle Method to get booking rides
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<BookingResponse> Handle(GetBookingRequest request, CancellationToken cancellationToken)
        {
            var bookingResponse = new BookingResponse();
            var predicates = new Dictionary<int, Func<BookingInfo, bool>> {
                { (int)UserRole.Admin ,  x => 1 == 1 },
                { (int)UserRole.Employee,  x => x.EmployeeId == request.bookingRequest.IdentityModel.UserId.ToString() || x.Status == "Pending"},
                { (int)UserRole.Customer,  x => x.CustomerId == request.bookingRequest.IdentityModel.UserId.ToString()}
            };

            var bookingQueryable = repository.Query<BookingInfo>()
                    .Where(predicates[request.bookingRequest.IdentityModel.RoleId])
                    .OrderBy(x => x.PickupDate)
                    .AsQueryable();

            var bookingInfoList = bookingQueryable
               .Skip(request.bookingRequest.PageSize * (request.bookingRequest.CurrentPage - 1))
               .Take(request.bookingRequest.PageSize)
               .ToList();

            var bookingList = mapper.Map<List<BookingInfo>, List<Booking>>(bookingInfoList);
            bookingResponse.BookingDetails = bookingList;
            bookingResponse.Count = bookingQueryable.Count();

            return await Task.FromResult(bookingResponse);
        }
    }
}