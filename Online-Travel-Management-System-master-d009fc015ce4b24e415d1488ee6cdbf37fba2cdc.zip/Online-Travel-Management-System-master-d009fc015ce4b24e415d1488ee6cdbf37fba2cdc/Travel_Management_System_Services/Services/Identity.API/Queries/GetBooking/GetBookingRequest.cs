﻿namespace Booking.Api.Queries.GetBooking
{
    using MediatR;
    using Booking.Domain.Dto;

    public class GetBookingRequest : IRequest<BookingResponse>
    {
        public BookingRequest bookingRequest { get; set; }

        ///<Summary>
        /// GetBookingByIdRequest constructor
        ///</Summary>  
        ///<param name="bookingRequest">bookingRequest</param>
        public GetBookingRequest(BookingRequest bookingRequest)
        {
            this.bookingRequest = bookingRequest;
        }
    }
}
