﻿namespace Booking.Api.Queries.CreateBooking
{
    using AutoMapper;
    using MediatR;
    using System.Threading.Tasks;
    using System.Threading;
    using System;
    using Booking.Domain.Dto;
    using Booking.Domain.Interfaces;
    using Booking.Domain.Aggregates.BookingInfo;

    /// <summary>
    /// CreateBooking class
    /// </summary>
    public class CreateBooking : IRequestHandler<CreateBookingRequest, Booking>
    {
        private IRepository repository;

        private IMapper mapper;

        /// <summary>
        /// CreateBooking constructor
        /// </summary>
        /// <param name="repository">IRepository</param>
        /// <param name="mapper">IMapper</param>
        public CreateBooking(IRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Handle method to create new ride
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<Booking> Handle(CreateBookingRequest request, CancellationToken cancellationToken)
        {
            var createBooking = mapper.Map<Booking, BookingInfo>(request.BookingRequest);

            createBooking.BookingId = GetBookingId();

            repository.Save(createBooking);

            var createBookingModel = mapper.Map<BookingInfo, Booking>(createBooking);

            return await Task.FromResult(createBookingModel);
        }

        private string GetBookingId()
        {
            return "BOOK" + Guid.NewGuid().ToString("N").Substring(0, 6).ToUpper();
        }
    }
}
