﻿namespace Booking.Domain.Aggregates.BookingInfo
{
    using System;

    public class BookingInfo
    {
        public BookingInfo(string bookingId, string customerId, string employeeId, string pickupLocation, string dropLocation, DateTime pickupDate, string pickupTime, string amount, string status)
        {
            BookingId = bookingId;
            CustomerId = customerId;
            EmployeeId = employeeId;
            PickupLocation = pickupLocation;
            DropLocation = dropLocation;
            PickupDate = pickupDate;
            PickupTime = pickupTime;
            Amount = amount;
            Status = status;
        }

        //for EF
        private BookingInfo() { }

        ///<Summary>
        /// Id
        ///</Summary>
        public Guid Id { get; set; }

        ///<Summary>
        /// Booking Id
        public string BookingId { get; set; }

        ///<Summary>
        /// CustomerId
        ///</Summary>
        public string CustomerId { get; set; }

        ///<Summary>
        /// EmployeeId
        ///</Summary>
        public string EmployeeId { get; set; }

        ///<Summary>
        /// PickupLocation
        ///</Summary>
        public string PickupLocation { get; set; }

        ///<Summary>
        /// DropLocation
        ///</Summary>
        public string DropLocation { get; set; }

        ///<Summary>
        /// PickupDate
        ///</Summary>
        public DateTime PickupDate { get; set; }

        ///<Summary>
        /// PickupTime
        ///</Summary>
        public string PickupTime { get; set; }

        ///<Summary>
        /// Amount
        ///</Summary>
        public string Amount { get; set; }

        ///<Summary>
        /// Status
        ///</Summary>
        public string Status { get; set; }
    }
}
