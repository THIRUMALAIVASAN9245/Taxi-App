﻿namespace Booking.Domain.Aggregates.ValueObjects
{
    public enum UserRole
    {
        Admin = 1,
        Employee = 2,
        Customer = 3
    }
}
