﻿namespace Booking.Domain.Dto
{
    using System;

    public class Booking
    {
        ///<Summary>
        /// Id
        ///</Summary>
        public Guid Id { get; set; }

        ///<Summary>
        /// Booking Id
        public string BookingId { get; set; }

        ///<Summary>
        /// CustomerId
        ///</Summary>
        public string CustomerId { get; set; }

        ///<Summary>
        /// EmployeeId
        ///</Summary>
        public string EmployeeId { get; set; }

        ///<Summary>
        /// PickupLocation
        ///</Summary>
        public string PickupLocation { get; set; }

        ///<Summary>
        /// DropLocation
        ///</Summary>
        public string DropLocation { get; set; }

        ///<Summary>
        /// PickupDate
        ///</Summary>
        public DateTime PickupDate { get; set; }

        ///<Summary>
        /// PickupTime
        ///</Summary>
        public string PickupTime { get; set; }

        ///<Summary>
        /// Amount
        ///</Summary>
        public string Amount { get; set; }

        ///<Summary>
        /// Status
        ///</Summary>
        public string Status { get; set; }
    }
}
