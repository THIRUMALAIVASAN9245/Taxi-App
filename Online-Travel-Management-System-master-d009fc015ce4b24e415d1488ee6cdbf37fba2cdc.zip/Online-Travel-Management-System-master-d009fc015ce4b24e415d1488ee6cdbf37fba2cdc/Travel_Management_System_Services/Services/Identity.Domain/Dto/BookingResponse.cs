﻿namespace Booking.Domain.Dto
{
    using System.Collections.Generic;

    public class BookingResponse
    {
        ///<Summary>
        /// BookingDetails
        ///</Summary>
        public List<Booking> BookingDetails { get; set; }

        ///<Summary>
        /// Booking Count
        ///</Summary>
        public int Count { get; set; }
    }
}