﻿namespace Booking.Domain.Dto
{
    public class BookingRequest
    {
        public int PageSize { get; set; }

        public int CurrentPage { get; set; }

        public IdentityModel IdentityModel { get; set; }
    }
}