﻿namespace Booking.Domain.Dto
{
    using System;

    public class IdentityModel
    {
        public int RoleId { get; set; }

        public Guid UserId { get; set; }
    }
}
