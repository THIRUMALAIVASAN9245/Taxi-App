﻿namespace Booking.Domain.MappingProfile
{
    using AutoMapper;
    using Booking.Domain.Dto;
    using Booking.Domain.Aggregates.BookingInfo;
    using System.Diagnostics.CodeAnalysis;

    public class BookingInfoProfile : Profile
    {
        /// <summary>
        /// VehicleInfoProfile Constructor
        /// </summary>
        [ExcludeFromCodeCoverage]
        public BookingInfoProfile()
        {
            CreateMap<Booking, BookingInfo>();

            CreateMap<BookingInfo, Booking>();
        }
    }
}