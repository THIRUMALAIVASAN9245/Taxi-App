﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Booking.Infrastructure.Migrations
{
    [ExcludeFromCodeCoverage]
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BookingInfo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    BookingId = table.Column<string>(maxLength: 10, nullable: false),
                    CustomerId = table.Column<string>(nullable: false),
                    EmployeeId = table.Column<string>(nullable: true),
                    PickupLocation = table.Column<string>(maxLength: 100, nullable: false),
                    DropLocation = table.Column<string>(nullable: true),
                    PickupDate = table.Column<DateTime>(nullable: false),
                    PickupTime = table.Column<string>(maxLength: 10, nullable: false),
                    Amount = table.Column<string>(nullable: true),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BookingInfo", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BookingInfo");
        }
    }
}
