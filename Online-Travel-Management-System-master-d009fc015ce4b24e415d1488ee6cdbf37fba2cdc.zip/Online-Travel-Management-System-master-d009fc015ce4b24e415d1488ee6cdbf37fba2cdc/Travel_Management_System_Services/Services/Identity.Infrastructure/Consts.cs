﻿namespace Booking.Infrastructure
{
    public static class Consts
    {
        public const string DbConfigKey = "BookingInfoDatabase";
    }
}
