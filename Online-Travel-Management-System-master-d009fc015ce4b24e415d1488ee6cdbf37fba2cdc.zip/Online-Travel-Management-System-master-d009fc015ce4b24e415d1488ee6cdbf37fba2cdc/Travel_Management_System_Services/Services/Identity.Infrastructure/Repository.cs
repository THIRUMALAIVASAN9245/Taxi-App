﻿namespace Booking.Infrastructure
{
    using System;
    using System.Linq;
    using Booking.Domain.Interfaces;
    using Booking.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.ChangeTracking;

    public class Repository : IRepository
    {
        private readonly BookingDbContext identityDbContext;

        public Repository(BookingDbContext identityDbContext)
        {
            this.identityDbContext = identityDbContext;
        }

        public IQueryable<T> Query<T>() where T : class
        {
            return identityDbContext.Set<T>().AsQueryable();
        }

        public T Get<T>(Guid key) where T : class
        {
            return this.identityDbContext.Set<T>().Find(key);
        }

        public T Save<T>(T entity) where T : class
        {
            var entityResult = identityDbContext.Set<T>().Add(entity).Entity;
            identityDbContext.SaveChanges();
            return entityResult;
        }

        public T Update<T>(T entity) where T : class
        {
            EntityEntry<T> entityEntry = identityDbContext.Entry(entity);
            identityDbContext.Set<T>().Attach(entity);
            entityEntry.State = EntityState.Modified;
            identityDbContext.SaveChanges();
            return entity;
        }
    }
}
