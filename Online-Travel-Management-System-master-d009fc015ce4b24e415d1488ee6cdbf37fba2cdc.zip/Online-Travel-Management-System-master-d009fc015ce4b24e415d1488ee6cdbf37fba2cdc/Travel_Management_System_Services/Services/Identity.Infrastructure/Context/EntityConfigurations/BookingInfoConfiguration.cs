﻿namespace Booking.Infrastructure.Context.EntityConfigurations
{
    using Booking.Domain.Aggregates.BookingInfo;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Diagnostics.CodeAnalysis;

    [ExcludeFromCodeCoverage]
    public class BookingInfoConfiguration : IEntityTypeConfiguration<BookingInfo>
    {
        public void Configure(EntityTypeBuilder<BookingInfo> builder)
        {
            builder.HasKey(s => new { s.Id });

            builder.Property(c => c.BookingId)
              .HasMaxLength(10)
              .IsRequired();

            builder.Property(c => c.CustomerId)
              .IsRequired();

            builder.Property(c => c.PickupLocation)
              .HasMaxLength(100)
              .IsRequired();

            builder.Property(c => c.PickupDate)
              .IsRequired();

            builder.Property(c => c.PickupTime)
              .HasMaxLength(10)
              .IsRequired();
        }
    }
}
