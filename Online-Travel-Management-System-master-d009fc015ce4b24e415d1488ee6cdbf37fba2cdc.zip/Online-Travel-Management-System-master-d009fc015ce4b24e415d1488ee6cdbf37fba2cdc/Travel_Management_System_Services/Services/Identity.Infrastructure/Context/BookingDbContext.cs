﻿namespace Booking.Infrastructure.Context
{
    using Booking.Domain.Aggregates.BookingInfo;
    using Booking.Infrastructure.Context.EntityConfigurations;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Booking context, provided by Entity Framework
    /// </summary>
    public class BookingDbContext : DbContext
    {
        ///<Summary>
        /// BookingDbContext constructor
        ///</Summary>
        public BookingDbContext() { }

        ///<Summary>
        /// BookingDbContext constructor with DbContextOptions
        ///</Summary>
        public BookingDbContext(DbContextOptions<BookingDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new BookingInfoConfiguration());
        }

        public DbSet<BookingInfo> BookingInfo { get; set; }
    }
}
