﻿namespace Booking.Infrastructure
{
    using System;
    using System.Data.SqlClient;
    using System.Diagnostics.CodeAnalysis;
    using Booking.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;

    /// <summary>s
    /// Static class, which provide Database seeding, and applying schemas
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class DbInitializer
    {
        public static void EnsureSchema(BookingDbContext context)
        {
            context.Database.Migrate();
        }

        public static void EnsureCreated(string connectionString)
        {
            if (!DatabaseExists(connectionString))
                CreateDatabase(connectionString);
        }

        private static void CreateDatabase(string connectionString)
        {
            var sqlConnectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

            var databaseName = sqlConnectionStringBuilder.InitialCatalog;

            sqlConnectionStringBuilder.InitialCatalog = "master";

            using (var sqlConnection = new SqlConnection(sqlConnectionStringBuilder.ConnectionString))
            {
                sqlConnection.Open();

                using (var sqlCommand = sqlConnection.CreateCommand())
                {
                    sqlCommand.CommandText = $"CREATE DATABASE {databaseName}";
                    sqlCommand.ExecuteNonQuery();
                }
            }
        }

        private static bool DatabaseExists(string connectionString)
        {
            var sqlConnectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

            var databaseName = sqlConnectionStringBuilder.InitialCatalog;

            sqlConnectionStringBuilder.InitialCatalog = "master";

            using (var sqlConnection = new SqlConnection(sqlConnectionStringBuilder.ConnectionString))
            {
                sqlConnection.Open();

                using (var command = sqlConnection.CreateCommand())
                {
                    command.CommandText = $"SELECT db_id('{databaseName}')";

                    return command.ExecuteScalar() != DBNull.Value;
                }
            }
        }
    }
}