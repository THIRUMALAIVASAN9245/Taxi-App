﻿namespace Identity.API.Controllers
{
    using System;
    using Microsoft.AspNetCore.Cors;
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using MediatR;
    using Microsoft.AspNetCore.Authorization;
    using Identity.Domain.Interfaces;
    using Identity.Domain.Dto;
    using Identity.API.Queries.CreateUser;
    using Identity.API.Queries.LoginUser;
    using Identity.API.Queries.GetUserInfo;
    using Microsoft.AspNetCore.Http;

    [Produces("application/json")]
    [Route("api/[controller]")]
    [EnableCors("CorsPolicy")]
    public class AuthServiceController : Controller
    {
        private readonly IMediator mediatR;

        private readonly ITokenGenerator tokenGenerator;

        /// <summary>
        /// AuthServiceController constructor
        /// </summary>
        /// <param name="mediatR"></param>
        /// <param name="tokenGenerator"></param>
        public AuthServiceController(IMediator mediatR, ITokenGenerator tokenGenerator)
        {
            this.mediatR = mediatR;
            this.tokenGenerator = tokenGenerator;
        }

        /// <summary>
        /// Create new user
        /// </summary>
        /// <param name="userModelRequest">Create new user</param>
        /// <returns>Saved user data object</returns>
        [HttpPost, Route("registration")]
        [ProducesResponseType(StatusCodes.Status201Created, Type = typeof(UserInfoModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> Post([FromBody]UserInfoModel userModelRequest)
        {
            var response = await mediatR.Send(new CreateUserRequest(userModelRequest));
            if (response == null)
            {
                return StatusCode(409, $"Error Occurred While Creating a User {userModelRequest.Email}");
            }

            return Created("user created", response);
        }

        /// <summary>
        /// verify user detail
        /// </summary>
        /// <param name="user">login user info</param>
        /// <returns>verify user detail</returns>
        [HttpPost, Route("login")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(UserInfoModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        public async Task<IActionResult> Login([FromBody]LoginRequestModel loginRequestModel)
        {
            var response = await mediatR.Send(new LoginUserRequest(loginRequestModel));
            if (response == null)
            {
                return NotFound($"User Id {loginRequestModel.Username} not found");
            }

            string userInfoWithToken = tokenGenerator.GetJwtTokenLoggedinUser(response);

            return Ok(userInfoWithToken);
        }

        /// <summary>
        /// Get user info
        /// </summary>
        /// <param name="getUserRequestModel">getUserRequestModel</param>
        /// <returns>Get userinfo details</returns>
        [Authorize]
        [HttpGet, Route("GetUserInfo")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(GetUserResponseModel))]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetUserInfo(GetUserRequestModel getUserRequestModel)
        {
            var response = await mediatR.Send(new GetUserInfoRequest(getUserRequestModel));

            return Ok(response);
        }
    }
}