﻿namespace Identity.API.Queries.CreateUser
{
    using AutoMapper;
    using MediatR;
    using System.Threading.Tasks;
    using System.Threading;
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Infrastructure.Helpers;

    /// <summary>
    /// CreateUser class
    /// </summary>
    public class CreateUser : IRequestHandler<CreateUserRequest, UserInfoModel>
    {
        private IRepository repository;

        private IMapper mapper;

        /// <summary>
        /// CreateUser constructor
        /// </summary>
        /// <param name="repository">IRepository</param>
        /// <param name="mapper">IMapper</param>
        public CreateUser(IRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Handle method to create new user
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<UserInfoModel> Handle(CreateUserRequest request, CancellationToken cancellationToken)
        {
            var createUser = mapper.Map<UserInfoModel, UserInfo>(request.UserRequest);

            byte[] passwordHash, passwordSalt;
            SecurePasswordHasherHelper.CreatePasswordHash(request.UserRequest.Password, out passwordHash, out passwordSalt);

            createUser.PasswordHash = passwordHash;
            createUser.PasswordSalt = passwordSalt;

            repository.Save(createUser);
            var responseUser = mapper.Map<UserInfo, UserInfoModel>(createUser);

            return await Task.FromResult(responseUser);
        }
    }
}