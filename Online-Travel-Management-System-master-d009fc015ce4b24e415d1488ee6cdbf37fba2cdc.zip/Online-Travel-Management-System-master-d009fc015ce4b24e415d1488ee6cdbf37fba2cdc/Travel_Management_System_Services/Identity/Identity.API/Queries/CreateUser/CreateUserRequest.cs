﻿namespace Identity.API.Queries.CreateUser
{
    using Identity.Domain.Dto;
    using MediatR;

    /// <summary>
    /// CreateUserRequest class
    /// </summary>
    public class CreateUserRequest : IRequest<UserInfoModel>
    {
        public UserInfoModel UserRequest { get; set; }

        ///<Summary>
        /// CreateUserRequest constructor
        ///</Summary>  
        ///<param name="userRequest">userRequest</param>
        public CreateUserRequest(UserInfoModel userRequest)
        {
            this.UserRequest = userRequest;
        }
    }
}