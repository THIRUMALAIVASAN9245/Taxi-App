﻿namespace Identity.API.Queries.LoginUser
{
    using Identity.Domain.Dto;
    using MediatR;

    /// <summary>
    /// LoginUserRequest class
    /// </summary>
    public class LoginUserRequest : IRequest<UserInfoModel>
    {
        public LoginRequestModel LoginRequestModel { get; set; }

        ///<Summary>
        /// LoginUserRequest constructor
        ///</Summary>  
        ///<param name="loginRequestModel">loginRequestModel</param>
        public LoginUserRequest(LoginRequestModel loginRequestModel)
        {
            this.LoginRequestModel = loginRequestModel;
        }
    }
}