﻿namespace Identity.API.Queries.LoginUser
{
    using AutoMapper;
    using MediatR;
    using System.Threading.Tasks;
    using System.Threading;
    using System.Linq;
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Infrastructure.Helpers;

    /// <summary>
    /// LoginUser class
    /// </summary>
    public class LoginUser : IRequestHandler<LoginUserRequest, UserInfoModel>
    {
        private IRepository repository;

        private IMapper mapper;

        /// <summary>
        /// LoginUser constructor
        /// </summary>
        /// <param name="repository">IRepository</param>
        /// <param name="mapper">IMapper</param>
        public LoginUser(IRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Handle method to verify user info
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<UserInfoModel> Handle(LoginUserRequest request, CancellationToken cancellationToken)
        {
            var userDetail = repository.Query<UserInfo>()
                .FirstOrDefault(user => user.Email == request.LoginRequestModel.Username);

            if (userDetail == null)
                return await Task.FromResult<UserInfoModel>(null);

            if (!SecurePasswordHasherHelper.VerifyPasswordHash(request.LoginRequestModel.Password, userDetail.PasswordHash, userDetail.PasswordSalt))
                return null;

            var createUserModel = mapper.Map<UserInfo, UserInfoModel>(userDetail);

            return await Task.FromResult(createUserModel);
        }
    }
}