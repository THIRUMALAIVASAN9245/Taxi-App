﻿namespace Identity.API.Queries.GetUserInfo
{
    using AutoMapper;
    using MediatR;
    using System.Threading.Tasks;
    using System.Threading;
    using System.Linq;
    using System;
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Identity.Domain.Aggregates.UserInfo;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// GetUserInfo class
    /// </summary>
    public class GetUserInfo : IRequestHandler<GetUserInfoRequest, GetUserResponseModel>
    {
        private IRepository repository;

        private IMapper mapper;

        /// <summary>
        /// LoginUser constructor
        /// </summary>
        /// <param name="repository">IRepository</param>
        /// <param name="mapper">IMapper</param>
        public GetUserInfo(IRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Handle method to get user info
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<GetUserResponseModel> Handle(GetUserInfoRequest request, CancellationToken cancellationToken)
        {
            var response = new GetUserResponseModel();
            var customerInfo = repository.Query<UserInfo>().Where(a => a.UserId == request.GetUserRequestModel.CustomerId);
            response.Customer = mapper.Map<UserInfo, UserInfoModel>(customerInfo.FirstOrDefault());
            if (request.GetUserRequestModel.EmployeeId != null && request.GetUserRequestModel.EmployeeId != Guid.Empty)
            {
                var employeeInfo = repository.Query<UserInfo>()
                    .Include(a => a.VehicleInfo)
                    .Where(a => a.UserId == request.GetUserRequestModel.EmployeeId);
                response.Employee = mapper.Map<UserInfo, UserInfoModel>(employeeInfo.FirstOrDefault());
            }

            return await Task.FromResult(response);
        }
    }
}