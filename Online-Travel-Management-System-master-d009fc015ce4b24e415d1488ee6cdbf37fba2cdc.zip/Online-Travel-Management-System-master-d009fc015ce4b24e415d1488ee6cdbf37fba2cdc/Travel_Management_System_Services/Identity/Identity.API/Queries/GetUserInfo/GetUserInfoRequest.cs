﻿namespace Identity.API.Queries.GetUserInfo
{
    using Identity.Domain.Dto;
    using MediatR;

    /// <summary>
    /// GetUserInfoRequest class
    /// </summary>
    public class GetUserInfoRequest : IRequest<GetUserResponseModel>
    {
        public GetUserRequestModel GetUserRequestModel { get; set; }

        ///<Summary>
        /// GetUserInfoRequest constructor
        ///</Summary>  
        ///<param name="getUserRequestModel">getUserRequestModel</param>
        public GetUserInfoRequest(GetUserRequestModel getUserRequestModel)
        {
            this.GetUserRequestModel = getUserRequestModel;
        }
    }
}
