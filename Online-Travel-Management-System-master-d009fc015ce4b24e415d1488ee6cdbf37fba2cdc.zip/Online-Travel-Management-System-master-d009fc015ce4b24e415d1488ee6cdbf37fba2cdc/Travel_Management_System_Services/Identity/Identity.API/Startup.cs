﻿namespace Identity.API
{
    using System;
    using Identity.API.Infrastructure.Filters;
    using FluentValidation.AspNetCore;
    using Identity.Infrastructure;
    using Identity.Infrastructure.Context;
    using MediatR;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Newtonsoft.Json.Serialization;
    using Swashbuckle.AspNetCore.Swagger;
    using AutoMapper;
    using Identity.Domain.Interfaces;
    using System.Reflection;
    using Identity.Domain.MappingProfile;
    using System.Text;
    using Microsoft.IdentityModel.Tokens;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using System.Diagnostics.CodeAnalysis;

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader());
            });

            var audience = Configuration.GetSection("Audience");
            var symmetrickey = audience["secret"];
            var byteArray = Encoding.ASCII.GetBytes(symmetrickey);
            var signingkey = new SymmetricSecurityKey(byteArray);
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingkey,
                ValidateIssuer = true,
                ValidIssuer = audience["issuer"],
                ValidateAudience = true,
                ValidAudience = audience["audience"],
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(5)
            };
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(o => o.TokenValidationParameters = tokenValidationParameters);

            services.AddAutoMapper(Assembly.GetAssembly(typeof(UserInfoProfile)));
            services.AddAutoMapper(Assembly.GetAssembly(typeof(UserInfoProfile)));
            services.AddScoped<IRepository, Repository>();
            services.AddScoped<ITokenGenerator, TokenGenerator>();
            services.AddMediatR(typeof(Startup));

            services.AddMvc(o => o.Filters.Add<HttpGlobalExceptionFilter>())
                .AddJsonOptions(o =>
                    o.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver())
                .AddFluentValidation(c => c.RegisterValidatorsFromAssembly(typeof(Startup).Assembly))
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1.0", new Info
                {
                    Version = "v1.0",
                    Title = "UserInfo API"
                });
            });

            var ree = Configuration.GetConnectionString(Consts.DbConfigKey);

            services.AddDbContext<IdentityDbContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString(Consts.DbConfigKey),
                    sqlOptions =>
                    {
                        sqlOptions.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null);
                    });
            });
        }

        [ExcludeFromCodeCoverage]
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors("CorsPolicy");

            // UserInfo api's ui view 
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1.0/swagger.json", "UserInfo API v1.0");
            });

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "api/{controller}/{action}/{id?}");
            });

            using (var scope = app.ApplicationServices.CreateScope())
            using (var dbContext = scope.ServiceProvider.GetRequiredService<IdentityDbContext>())
            {
                DbInitializer.EnsureCreated(Configuration.GetConnectionString(Consts.DbConfigKey));
                DbInitializer.EnsureSchema(dbContext);
                DbInitializer.SeedDatabase(dbContext);
            }
        }
    }
}
