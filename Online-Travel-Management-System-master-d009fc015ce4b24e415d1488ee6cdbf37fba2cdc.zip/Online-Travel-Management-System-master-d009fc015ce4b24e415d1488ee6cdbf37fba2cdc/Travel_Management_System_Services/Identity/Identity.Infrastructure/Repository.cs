﻿namespace Identity.Infrastructure
{
    using System;
    using System.Linq;
    using Identity.Domain.Interfaces;
    using Identity.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.ChangeTracking;

    public class Repository : IRepository
    {
        private readonly IdentityDbContext identityDbContext;

        public Repository(IdentityDbContext identityDbContext)
        {
            this.identityDbContext = identityDbContext;
        }

        public IQueryable<T> Query<T>() where T : class
        {
            return identityDbContext.Set<T>().AsQueryable();
        }

        public T Get<T>(Guid key) where T : class
        {
            return this.identityDbContext.Set<T>().Find(key);
        }

        public T Save<T>(T entity) where T : class
        {
            var entityResult = identityDbContext.Set<T>().Add(entity).Entity;
            identityDbContext.SaveChanges();
            return entityResult;
        }

        public T Update<T>(T entity) where T : class
        {
            EntityEntry<T> entityEntry = identityDbContext.Entry(entity);
            identityDbContext.Set<T>().Attach(entity);
            entityEntry.State = EntityState.Modified;
            identityDbContext.SaveChanges();
            return entity;
        }
    }
}
