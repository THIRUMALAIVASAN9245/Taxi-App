﻿namespace Identity.Infrastructure
{
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Microsoft.IdentityModel.Tokens;
    using Newtonsoft.Json;
    using System;
    using System.IdentityModel.Tokens.Jwt;
    using System.Security.Claims;
    using System.Text;

    public class TokenGenerator : ITokenGenerator
    {
        public string GetJwtTokenLoggedinUser(UserInfoModel userModel)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("Taxi_Booking_Security_Key"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: "issuerTest",
                audience: "audienceTest",
                expires: DateTime.UtcNow.AddMinutes(20),
                signingCredentials: creds,
                claims: Claims(userModel)
            );
            var response = new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                userDetails = userModel
            };

            return JsonConvert.SerializeObject(response);
        }

        private static Claim[] Claims(UserInfoModel userInfoModel)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.UniqueName, userInfoModel.UserId.ToString()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim("userId", userInfoModel.UserId.ToString()),
                new Claim("firstName", userInfoModel.FirstName),
                new Claim("lastName", userInfoModel.LastName),
                new Claim("email", userInfoModel.Email),
                new Claim("roleId", userInfoModel.RoleId.ToString())
            };
            return claims;
        }
    }
}