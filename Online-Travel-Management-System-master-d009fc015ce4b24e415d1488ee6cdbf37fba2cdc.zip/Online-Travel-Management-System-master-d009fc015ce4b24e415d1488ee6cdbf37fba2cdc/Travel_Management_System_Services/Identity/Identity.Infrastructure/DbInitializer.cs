﻿namespace Identity.Infrastructure
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Data.SqlClient;
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using Identity.Domain.Aggregates.VehicleInfo;
    using Identity.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Internal;
    using Identity.Infrastructure.Helpers;

    /// <summary>
    /// Static class, which provide Database seeding, and applying schemas
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class DbInitializer
    {
        public static void SeedDatabase(IdentityDbContext context)
        {
            if (!context.UserInfo.Any())
            {
                byte[] passwordHash, passwordSalt;
                SecurePasswordHasherHelper.CreatePasswordHash("test@123", out passwordHash, out passwordSalt);

                var userAdmin = new UserInfo("Admin", "Admin", "Male", 1234567891, new DateTime(1992, 05, 27), "admin@test.com", passwordHash, passwordSalt, UserRoleType.Admin, "Active");
                var userCustomer = new UserInfo("Thirumalai", "Vasan", "Male", 1234567891, new DateTime(1992, 05, 27), "thirumalai@test.com", passwordHash, passwordSalt, UserRoleType.Customer, "Active");
                var userEmployee = new UserInfo("Rathish", "R", "Male", 1234567891, new DateTime(1992, 05, 27), "rathish@test.com", passwordHash, passwordSalt, UserRoleType.Employee, "Active");

                userEmployee.AddVehicleInfo(new VehicleInfo("TN 83 7878", "TN 83 43434343", "Tamil Nadu", "All", "Yes", "NA"));

                var userRole1 = new UserRole(UserRoleType.Admin.ToString());
                var userRole2 = new UserRole(UserRoleType.Employee.ToString());
                var userRole3 = new UserRole(UserRoleType.Customer.ToString());

                context.UserRole.Add(userRole1);
                context.UserRole.Add(userRole2);
                context.UserRole.Add(userRole3);

                context.UserInfo.Add(userAdmin);
                context.UserInfo.Add(userCustomer);
                context.UserInfo.Add(userEmployee);

                context.SaveChanges();
            }
        }

        public static void EnsureSchema(IdentityDbContext context)
        {
            context.Database.Migrate();
        }

        public static void EnsureCreated(string connectionString)
        {
            if (!DatabaseExists(connectionString))
                CreateDatabase(connectionString);
        }

        private static void CreateDatabase(string connectionString)
        {
            var sqlConnectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

            var databaseName = sqlConnectionStringBuilder.InitialCatalog;

            sqlConnectionStringBuilder.InitialCatalog = "master";

            using (var sqlConnection = new SqlConnection(sqlConnectionStringBuilder.ConnectionString))
            {
                sqlConnection.Open();

                using (var sqlCommand = sqlConnection.CreateCommand())
                {
                    sqlCommand.CommandText = $"CREATE DATABASE {databaseName}";
                    sqlCommand.ExecuteNonQuery();
                }
            }
        }

        private static bool DatabaseExists(string connectionString)
        {
            var sqlConnectionStringBuilder = new SqlConnectionStringBuilder(connectionString);

            var databaseName = sqlConnectionStringBuilder.InitialCatalog;

            sqlConnectionStringBuilder.InitialCatalog = "master";

            using (var sqlConnection = new SqlConnection(sqlConnectionStringBuilder.ConnectionString))
            {
                sqlConnection.Open();

                using (var command = sqlConnection.CreateCommand())
                {
                    command.CommandText = $"SELECT db_id('{databaseName}')";

                    return command.ExecuteScalar() != DBNull.Value;
                }
            }
        }
    }
}