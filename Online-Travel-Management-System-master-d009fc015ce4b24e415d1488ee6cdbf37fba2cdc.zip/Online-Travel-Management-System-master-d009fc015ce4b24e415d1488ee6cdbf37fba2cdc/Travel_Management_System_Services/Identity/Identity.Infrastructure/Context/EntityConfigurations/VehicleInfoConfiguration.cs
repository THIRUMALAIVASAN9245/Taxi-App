﻿namespace Identity.Infrastructure.Context.EntityConfigurations
{
    using Identity.Domain.Aggregates.VehicleInfo;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Diagnostics.CodeAnalysis;

    [ExcludeFromCodeCoverage]
    public class VehicleInfoConfiguration : IEntityTypeConfiguration<VehicleInfo>
    {
        public void Configure(EntityTypeBuilder<VehicleInfo> builder)
        {
            builder.HasKey(s => new { s.Id });

            builder.Property(c => c.VehicleNumber)
              .HasMaxLength(10)
              .IsRequired();

            builder.Property(c => c.Insurance)
              .HasMaxLength(15)
              .IsRequired();

            builder.Property(c => c.License)
              .HasMaxLength(15)
              .IsRequired();

            builder.Property(c => c.Permit)
              .HasMaxLength(30)
              .IsRequired();

            builder.Property(c => c.Registration)
              .HasMaxLength(10)
              .IsRequired();
        }
    }
}
