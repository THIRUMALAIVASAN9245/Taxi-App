﻿namespace Identity.Infrastructure.Context.EntityConfigurations
{
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.VehicleInfo;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System.Diagnostics.CodeAnalysis;

	[ExcludeFromCodeCoverage]
    public class UserInfoConfiguration : IEntityTypeConfiguration<UserInfo>
    {
        public void Configure(EntityTypeBuilder<UserInfo> builder)
        {
            builder.HasKey(s => new { s.UserId });

            builder.Property(c => c.FirstName)
              .HasMaxLength(30)
              .IsRequired();

            builder.Property(c => c.LastName)
             .HasMaxLength(30)
             .IsRequired();

            builder.Property(c => c.PhoneNumber)
              .HasMaxLength(10)
              .IsRequired();

            builder.Property(c => c.Email)
                .HasMaxLength(25)
                .IsRequired();

            //uniqueness constraint
            builder.HasIndex(c => c.Email)
                .IsUnique();

            builder.Property(c => c.PasswordHash)
               .IsRequired();

            builder.Property(c => c.PasswordSalt)
               .IsRequired();

            builder.Property(c => c.DateOfBirth)
               .IsRequired();

            builder.Property(c => c.RoleId)
              .IsRequired();

            builder.HasOne(a => a.VehicleInfo)
                .WithOne(b => b.UserInfo)
                .HasForeignKey<VehicleInfo>(b => b.UserId);
        }
    }
}
