﻿namespace Identity.Infrastructure.Context
{
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.VehicleInfo;
    using Identity.Infrastructure.Context.EntityConfigurations;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Identit context, provided by Entity Framework
    /// </summary>
    public class IdentityDbContext : DbContext
    {
        ///<Summary>
        /// IdentityDbContext constructor
        ///</Summary>
        public IdentityDbContext() { }

        ///<Summary>
        /// IdentityDbContext constructor with DbContextOptions
        ///</Summary>
        public IdentityDbContext(DbContextOptions<IdentityDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new UserInfoConfiguration());
            modelBuilder.ApplyConfiguration(new VehicleInfoConfiguration());
            modelBuilder.ApplyConfiguration(new UserRoleConfiguration());
        }


        public DbSet<UserInfo> UserInfo { get; set; }
        public DbSet<VehicleInfo> VehicleInfo { get; set; }
        public DbSet<UserRole> UserRole { get; set; }
    }
}
