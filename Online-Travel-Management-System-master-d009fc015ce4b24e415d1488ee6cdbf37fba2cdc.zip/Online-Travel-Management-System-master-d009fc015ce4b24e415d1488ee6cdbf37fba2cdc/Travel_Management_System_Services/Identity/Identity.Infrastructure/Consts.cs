﻿namespace Identity.Infrastructure
{
    public static class Consts
    {
        public const string DbConfigKey = "UserInfoDatabase";
    }
}
