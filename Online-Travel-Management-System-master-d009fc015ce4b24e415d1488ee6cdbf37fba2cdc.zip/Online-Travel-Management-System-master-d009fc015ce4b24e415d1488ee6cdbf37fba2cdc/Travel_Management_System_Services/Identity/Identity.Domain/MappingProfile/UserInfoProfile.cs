﻿namespace Identity.Domain.MappingProfile
{
    using System.Diagnostics.CodeAnalysis;
    using AutoMapper;
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Dto;

    public class UserInfoProfile : Profile
    {
        /// <summary>
        /// VehicleInfoProfile Constructor
        /// </summary>
        [ExcludeFromCodeCoverage]
        public UserInfoProfile()
        {
            CreateMap<UserInfoModel, UserInfo>();

            CreateMap<UserInfo, UserInfoModel>();
        }
    }
}