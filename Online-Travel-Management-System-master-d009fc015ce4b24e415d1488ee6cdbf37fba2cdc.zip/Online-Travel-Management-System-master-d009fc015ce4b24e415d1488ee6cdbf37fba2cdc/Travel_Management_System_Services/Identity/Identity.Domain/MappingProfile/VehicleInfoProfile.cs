﻿namespace Identity.Domain.MappingProfile
{
    using AutoMapper;
    using Identity.Domain.Aggregates.VehicleInfo;
    using Identity.Domain.Dto;
    using System.Diagnostics.CodeAnalysis;

    public class VehicleInfoProfile : Profile
    {
        /// <summary>
        /// VehicleInfoProfile Constructor
        /// </summary>
        [ExcludeFromCodeCoverage]
        public VehicleInfoProfile()
        {
            CreateMap<VehicleModel, VehicleInfo>();

            CreateMap<VehicleInfo, VehicleModel>();
        }
    }
}