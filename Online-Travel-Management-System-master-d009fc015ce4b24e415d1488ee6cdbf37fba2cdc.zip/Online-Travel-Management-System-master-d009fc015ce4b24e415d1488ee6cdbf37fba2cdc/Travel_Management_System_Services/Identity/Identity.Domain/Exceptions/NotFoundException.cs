﻿namespace Identity.Domain.Exceptions
{
    using System;
    using System.Diagnostics.CodeAnalysis;

    /// <summary>
    /// Domain specific exception which means that entity is not found by specified parameters
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class NotFoundException : Exception
    {
        public NotFoundException()
            : base("Some parameter is invalid in request.")
        {

        }

        public NotFoundException(string message)
            : base(message)
        {
        }

        public NotFoundException(string message, Exception innerException)
            : base(message, innerException)
        {

        }
    }
}
