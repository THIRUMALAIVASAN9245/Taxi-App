﻿namespace Identity.Domain.Dto
{
    using System;

    public class UserInfoModel
    {
        ///<Summary>
        /// Id
        ///</Summary>
        public Guid UserId { get; set; }

        ///<Summary>
        /// FirstName
        ///</Summary>
        public string FirstName { get; set; }

        ///<Summary>
        /// LastName
        ///</Summary>
        public string LastName { get; set; }

        ///<Summary>
        /// Gender
        ///</Summary>
        public string Gender { get; set; }

        ///<Summary>
        /// PhoneNumber
        ///</Summary>
        public Int32 PhoneNumber { get; set; }

        ///<Summary>
        /// DateOfBirth
        ///</Summary>
        public DateTime DateOfBirth { get; set; }

        ///<Summary>
        /// Email
        ///</Summary>
        public string Email { get; set; }

        ///<Summary>
        /// Password
        ///</Summary>
        public string Password { get; set; }

        ///<Summary>
        /// ConfirmPassword
        ///</Summary>
        public string ConfirmPassword { get; set; }

        ///<Summary>
        /// RoleId
        ///</Summary>
        public int RoleId { get; set; }

        ///<Summary>
        /// Status
        ///</Summary>
        public string Status { get; set; }

        ///<Summary>
        /// VehicleModel
        ///</Summary>
        public VehicleModel VehicleInfo { get; set; }
    }
}