﻿namespace Identity.Domain.Dto
{
    using System;

    public class GetUserRequestModel
    {
        ///<Summary>
        /// CustomerId
        ///</Summary>
        public Guid CustomerId { get; set; }

        ///<Summary>
        /// EmployeeId
        ///</Summary>
        public Guid EmployeeId { get; set; }
    }
}
