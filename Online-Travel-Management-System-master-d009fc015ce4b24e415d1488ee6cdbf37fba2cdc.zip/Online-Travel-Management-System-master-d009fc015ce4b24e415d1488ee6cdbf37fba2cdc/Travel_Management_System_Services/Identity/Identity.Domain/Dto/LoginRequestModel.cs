﻿namespace Identity.Domain.Dto
{
    public class LoginRequestModel
    {
        ///<Summary>
        /// Username
        ///</Summary>
        public string Username { get; set; }

        ///<Summary>
        /// Password
        ///</Summary>
        public string Password { get; set; }
    }
}
