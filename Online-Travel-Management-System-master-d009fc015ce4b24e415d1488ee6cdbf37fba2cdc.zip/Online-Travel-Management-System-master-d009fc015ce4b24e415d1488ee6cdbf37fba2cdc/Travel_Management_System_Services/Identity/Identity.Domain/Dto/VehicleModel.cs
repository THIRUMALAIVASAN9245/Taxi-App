﻿namespace Identity.Domain.Dto
{
    using System;

    public class VehicleModel
    {
        ///<Summary>
        /// UserId
        ///</Summary>
        public Guid UserId { get; set; }

        ///<Summary>
        /// VehicleNumber
        ///</Summary>
        public string VehicleNumber { get; set; }

        ///<Summary>
        /// License
        ///</Summary>
        public string License { get; set; }

        ///<Summary>
        /// Insurance
        ///</Summary>
        public string Insurance { get; set; }

        ///<Summary>
        /// Permit
        ///</Summary>
        public string Permit { get; set; }

        ///<Summary>
        /// Registration
        ///</Summary>
        public string Registration { get; set; }

        ///<Summary>
        /// Description
        ///</Summary>
        public string Description { get; set; }
    }
}