﻿namespace Identity.Domain.Dto
{
    public class GetUserResponseModel
    {
        ///<Summary>
        /// Customer
        ///</Summary>
        public UserInfoModel Customer { get; set; }

        ///<Summary>
        /// Employee
        ///</Summary>
        public UserInfoModel Employee { get; set; }
    }
}
