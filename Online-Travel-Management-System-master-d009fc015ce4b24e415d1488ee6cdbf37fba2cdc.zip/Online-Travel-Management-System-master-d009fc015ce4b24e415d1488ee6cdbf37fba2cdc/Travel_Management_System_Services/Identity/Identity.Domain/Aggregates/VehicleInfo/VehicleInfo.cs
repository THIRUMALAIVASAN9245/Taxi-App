﻿namespace Identity.Domain.Aggregates.VehicleInfo
{
    using System;
    using Identity.Domain.Aggregates.UserInfo;

    public class VehicleInfo
    {
        public VehicleInfo(string vehicleNumber, string license, string insurance, string permit, string registration, string description)
        {
            VehicleNumber = vehicleNumber;
            License = license;
            Insurance = insurance;
            Permit = permit;
            Registration = registration;
            Description = description;
        }

        //for EF
        private VehicleInfo() { }

        ///<Summary>
        /// Id
        ///</Summary>
        public Guid Id { get; set; }

        ///<Summary>
        /// VehicleNumber
        ///</Summary>
        public string VehicleNumber { get; set; }

        ///<Summary>
        /// License
        ///</Summary>
        public string License { get; set; }

        ///<Summary>
        /// Insurance
        ///</Summary>
        public string Insurance { get; set; }

        ///<Summary>
        /// Permit
        ///</Summary>
        public string Permit { get; set; }

        ///<Summary>
        /// Registration
        ///</Summary>
        public string Registration { get; set; }

        ///<Summary>
        /// Description
        ///</Summary>
        public string Description { get; set; }

        ///<Summary>
        /// UserId
        ///</Summary>
        public Guid UserId { get; set; }

        ///<Summary>
        /// UserInfo
        ///</Summary>
        public UserInfo UserInfo { get; private set; }
    }
}
