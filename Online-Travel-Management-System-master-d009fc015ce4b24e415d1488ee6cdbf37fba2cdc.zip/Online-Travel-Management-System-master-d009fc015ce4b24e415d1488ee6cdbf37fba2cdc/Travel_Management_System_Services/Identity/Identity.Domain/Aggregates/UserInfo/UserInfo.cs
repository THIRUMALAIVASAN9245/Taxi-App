﻿namespace Identity.Domain.Aggregates.UserInfo
{
    using System;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using Identity.Domain.Aggregates.VehicleInfo;

    public class UserInfo
    {
        public UserInfo(string firstName, string lastName, string gender, long phoneNumber, DateTime dateOfBirth, string email, byte[] passwordHash, byte[] passwordSalt, UserRoleType roleId, string status)
        {
            FirstName = firstName;
            LastName = lastName;
            Gender = gender;
            PhoneNumber = phoneNumber;
            DateOfBirth = dateOfBirth;
            Email = email;
            PasswordHash = passwordHash;
            PasswordSalt = passwordSalt;
            RoleId = roleId;
            Status = status;
        }

        //for EF
        private UserInfo() { }

        ///<Summary>
        /// Id
        ///</Summary>
        public Guid UserId { get; set; }

        ///<Summary>
        /// FirstName
        ///</Summary>
        public string FirstName { get; set; }

        ///<Summary>
        /// LastName
        ///</Summary>
        public string LastName { get; set; }

        ///<Summary>
        /// Gender
        ///</Summary>
        public string Gender { get; set; }

        ///<Summary>
        /// PhoneNumber
        ///</Summary>
        public long PhoneNumber { get; set; }

        ///<Summary>
        /// DateOfBirth
        ///</Summary>
        public DateTime DateOfBirth { get; set; }

        ///<Summary>
        /// Email
        ///</Summary>
        public string Email { get; set; }

        ///<Summary>
        /// Password
        ///</Summary>
        public byte[] PasswordHash { get; set; }

        ///<Summary>
        /// ConfirmPassword
        ///</Summary>
        public byte[] PasswordSalt { get; set; }

        ///<Summary>
        /// RoleId
        ///</Summary>
        public UserRoleType RoleId { get; set; }

        ///<Summary>
        /// Status
        ///</Summary>
        public string Status { get; set; }

        ///<Summary>
        /// VehicleInfo
        ///</Summary>
        public VehicleInfo VehicleInfo { get; private set; }

        /// <summary>
        /// Add vehicleInfo to userinfo
        /// </summary>
        /// <param name="vehicleInfo">VehicleInfo to add</param>
        public void AddVehicleInfo(VehicleInfo vehicleInfo)
        {
            if (VehicleInfo == null)
                VehicleInfo = vehicleInfo;
        }
    }
}
