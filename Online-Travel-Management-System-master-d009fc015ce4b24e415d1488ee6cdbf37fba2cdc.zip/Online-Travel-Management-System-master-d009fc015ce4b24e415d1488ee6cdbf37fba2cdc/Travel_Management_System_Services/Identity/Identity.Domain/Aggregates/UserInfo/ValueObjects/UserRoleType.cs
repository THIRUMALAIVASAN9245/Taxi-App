﻿namespace Identity.Domain.Aggregates.UserInfo.ValueObjects
{
    public enum UserRoleType
    {
        Admin = 1,
        Employee = 2,
        Customer = 3
    }
}
