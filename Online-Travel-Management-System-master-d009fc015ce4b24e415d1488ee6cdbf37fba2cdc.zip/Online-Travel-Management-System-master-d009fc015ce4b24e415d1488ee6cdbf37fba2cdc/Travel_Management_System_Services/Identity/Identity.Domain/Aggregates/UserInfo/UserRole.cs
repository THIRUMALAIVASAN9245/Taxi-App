﻿namespace Identity.Domain.Aggregates.UserInfo
{
    public class UserRole
    {
        public UserRole(string userRoleType)
        {
            UserRoleType = userRoleType;
        }

        public int Id { get; set; }
        public string UserRoleType { get; set; }
    }
}