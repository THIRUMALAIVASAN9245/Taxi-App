﻿namespace Identity.Domain.Interfaces
{
    using System;
    using System.Linq;

    public interface IRepository
    {
        IQueryable<T> Query<T>() where T : class;

        T Get<T> (Guid key) where T : class;

        T Save<T>(T entity) where T : class;

        T Update<T>(T entity) where T : class;        
    }
}
