﻿namespace Identity.Domain.Interfaces
{
    using Identity.Domain.Dto;

    public interface ITokenGenerator
    {
        string GetJwtTokenLoggedinUser(UserInfoModel userModel);
    }
}