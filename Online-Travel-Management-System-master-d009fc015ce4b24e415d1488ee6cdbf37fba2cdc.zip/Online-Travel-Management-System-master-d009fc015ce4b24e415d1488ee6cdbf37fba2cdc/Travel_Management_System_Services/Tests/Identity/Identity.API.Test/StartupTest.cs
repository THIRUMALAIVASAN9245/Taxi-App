﻿namespace Identity.API.Test
{
    using Xunit;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Moq;
    using Identity.API.Controllers;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;

    public class StartupTest
    {
        private Mock<IApplicationBuilder> applicationBuilder;

        private Mock<IHostingEnvironment> hostingEnvironment;

        [Fact]
        public void ConfigureServicesAsExpected()
        {
            // Arrange
            Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
            Mock<IConfigurationSection> configurationSectionStub = new Mock<IConfigurationSection>();

            configurationSectionStub.Setup(x => x["secret"]).Returns("testSecret");
            configurationSectionStub.Setup(x => x["issuer"]).Returns("testIssuer");
            configurationSectionStub.Setup(x => x["audience"]).Returns("testAudience");
            configurationStub.Setup(x => x.GetSection("Audience")).Returns(configurationSectionStub.Object);

            configurationSectionStub.Setup(x => x["DefaultConnection"]).Returns("DefaultConnectionString");
            configurationStub.Setup(x => x.GetSection("ConnectionStrings")).Returns(configurationSectionStub.Object);

            IServiceCollection services = new ServiceCollection();
            Startup startup = new Startup(configurationStub.Object);

            //  Act
            startup.ConfigureServices(services);
            services.AddTransient<AuthServiceController>();

            //  Assert
            ServiceProvider serviceProvider = services.BuildServiceProvider();
            var controller = serviceProvider.GetService<AuthServiceController>();
            Assert.NotNull(controller);
        }

        //[Fact]
        //public void Should_Redirect_Permanently()
        //{
        //    // Arrange
        //    Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
        //    Startup startup = new Startup(configurationStub.Object);

        //    hostingEnvironment = new Mock<IHostingEnvironment>();
        //    applicationBuilder = new Mock<IApplicationBuilder>();

        //    applicationBuilder.Setup(x => x.UseMvc()).Returns(applicationBuilder.Object);

        //    //  Act
        //    startup.Configure(applicationBuilder.Object, hostingEnvironment.Object);
        //}
    }
}
