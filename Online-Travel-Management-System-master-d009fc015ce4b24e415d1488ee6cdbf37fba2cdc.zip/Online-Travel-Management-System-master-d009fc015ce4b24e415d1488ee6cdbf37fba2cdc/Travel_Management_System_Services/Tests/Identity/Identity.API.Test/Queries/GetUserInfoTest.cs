namespace Identity.API.Test.Queries
{
    using AutoMapper;
    using Identity.API.Queries.GetUserInfo;
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Identity.Infrastructure.Helpers;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Xunit;

    public class GetUserInfoTest
    {
        private GetUserInfoRequest request;

        private GetUserInfo underTest;

        private Mock<IRepository> repository;

        [Fact]
        public async Task HandleWithValidGetUserInfoRequestCallSaveAsExpectedResultAsync()
        {
            // Arrange                    
            var getUserRequest = new GetUserRequestModel { CustomerId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2") };
            var config = new MapperConfiguration(m => { m.CreateMap<UserInfo, UserInfoModel>(); m.CreateMap<UserInfoModel, UserInfo>(); });
            var mapper = new Mapper(config);
            var userDetail = MockUserListResponse().ToList().AsQueryable();
            repository = new Mock<IRepository>();
            repository.Setup(m => m.Query<UserInfo>()).Returns(userDetail);

            underTest = new GetUserInfo(repository.Object, mapper);
            request = new GetUserInfoRequest(getUserRequest);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
            Assert.NotNull(result.Customer);
        }

        [Fact]
        public async Task HandleWithGetByCustomerValidCustomerIdAndEmployeeIdCallSaveAsExpectedResultAsync()
        {
            // Arrange                    
            var getUserRequest = new GetUserRequestModel
            {
                CustomerId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2"),
                EmployeeId = new Guid("b5b6ebd7-8556-441d-5063-08d77952a241")
            };
            var config = new MapperConfiguration(m => { m.CreateMap<UserInfo, UserInfoModel>(); m.CreateMap<UserInfoModel, UserInfo>(); });
            var mapper = new Mapper(config);
            var userDetail = MockUserListResponse().ToList().AsQueryable();
            repository = new Mock<IRepository>();
            repository.Setup(m => m.Query<UserInfo>()).Returns(userDetail);

            underTest = new GetUserInfo(repository.Object, mapper);
            request = new GetUserInfoRequest(getUserRequest);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);			
            Assert.NotNull(result.Customer);
            Assert.NotNull(result.Employee);
        }

        private static List<UserInfo> MockUserListResponse()
        {
            byte[] passwordHash, passwordSalt;
            SecurePasswordHasherHelper.CreatePasswordHash("test@123", out passwordHash, out passwordSalt);

            var userAdmin = new UserInfo("Admin", "Admin", "Male", 1234567891, new DateTime(1992, 05, 27), "admin@test.com", passwordHash, passwordSalt, UserRoleType.Admin, "Active");
            var userCustomer = new UserInfo("Thirumalai", "Vasan", "Male", 1234567891, new DateTime(1992, 05, 27), "thirumalai@test.com", passwordHash, passwordSalt, UserRoleType.Customer, "Active");
            var userEmployee = new UserInfo("Rathish", "R", "Male", 1234567891, new DateTime(1992, 05, 27), "rathish@test.com", passwordHash, passwordSalt, UserRoleType.Employee, "Active");

            userAdmin.UserId = new Guid("4f62e36b-8e36-4a45-4e29-08d778e70ca2");
            userCustomer.UserId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2");
            userEmployee.UserId = new Guid("b5b6ebd7-8556-441d-5063-08d77952a241");

            var userList = new List<UserInfo>
            {
                userAdmin,
                userCustomer,
                userEmployee
            };

            return userList;
        }
    }
}