namespace Identity.API.Test.Queries
{
    using AutoMapper;
    using Identity.API.Queries.CreateUser;
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.VehicleInfo;
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Xunit;

    public class CreateUserTest
    {
        private CreateUserRequest request;

        private CreateUser underTest;

        private Mock<IRepository> repository;

        [Fact]
        public async Task HandleWithValidCreateRequestCallSaveAsExpectedResultAsync()
        {
            // Arrange
            var vehicleModel = new VehicleModel()
            {
                VehicleNumber = "TN323G3332",
                Registration = "TN",
                Insurance = "YES",
                License = "YES",
                Permit = "INDIA",
                UserId = new Guid("b5b6ebd7-8556-441d-5063-08d77952a241"),
                Description = "Test"
            };
            var userModel = new UserInfoModel { FirstName = "Thirumalai", Password = "test@123", VehicleInfo = vehicleModel };

            var config = new MapperConfiguration(m => { m.CreateMap<UserInfoModel, UserInfo>(); m.CreateMap<UserInfo, UserInfoModel>(); m.CreateMap<VehicleModel, VehicleInfo>(); m.CreateMap<VehicleInfo, VehicleModel>(); });
            var mapper = new Mapper(config);
            var UserList = MockUserListResponse().ToList().AsQueryable();

            repository = new Mock<IRepository>();
            repository.Setup(m => m.Save<UserInfoModel>(userModel))
              .Returns(UserList.AsQueryable().FirstOrDefault());

            underTest = new CreateUser(repository.Object, mapper);
            request = new CreateUserRequest(userModel);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
            Assert.Equal(userModel.FirstName, result.FirstName);
        }

        private static List<UserInfoModel> MockUserListResponse()
        {
            var userList = new List<UserInfoModel>
            {
                new UserInfoModel
                {
                     FirstName = "Vasan"
                },
                new UserInfoModel
                {
                    FirstName = "Rathish"
                }
            };

            return userList;
        }
    }
}