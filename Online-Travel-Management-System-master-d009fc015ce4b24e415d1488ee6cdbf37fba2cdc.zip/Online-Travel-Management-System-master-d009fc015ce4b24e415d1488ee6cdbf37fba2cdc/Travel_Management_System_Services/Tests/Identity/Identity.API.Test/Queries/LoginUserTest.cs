namespace Identity.API.Test.Queries
{
    using AutoMapper;
    using Identity.API.Queries.LoginUser;
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Identity.Infrastructure.Helpers;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Xunit;

    public class LoginUserTest
    {
        private LoginUserRequest request;

        private LoginUser underTest;

        private Mock<IRepository> repository;

        [Fact]
        public async Task HandleWithValidCreateRequestCallAsExpectedResultAsync()
        {
            // Arrange                    
            var userModel = new LoginRequestModel { Username = "thirumalai@test.com", Password = "test@123" };

            var config = new MapperConfiguration(m => { m.CreateMap<UserInfo, UserInfoModel>(); });
            var mapper = new Mapper(config);
            var bookingList = MockUserListResponse().ToList().AsQueryable();

            repository = new Mock<IRepository>();
            repository.Setup(m => m.Query<UserInfo>())
              .Returns(bookingList);

            underTest = new LoginUser(repository.Object, mapper);
            request = new LoginUserRequest(userModel);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
        }

        [Fact]
        public async Task HandleWithValidCreateRequestCallAsExpectedInValidUserAsync()
        {
            // Arrange                    
            var userModel = new LoginRequestModel { Username = "invalid@test.com", Password = "test@123" };

            var config = new MapperConfiguration(m => { m.CreateMap<UserInfo, UserInfoModel>(); });
            var mapper = new Mapper(config);
            var bookingList = MockUserListResponse().ToList().AsQueryable();

            repository = new Mock<IRepository>();
            repository.Setup(m => m.Query<UserInfo>())
              .Returns(bookingList);

            underTest = new LoginUser(repository.Object, mapper);
            request = new LoginUserRequest(userModel);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.Null(result);
        }

        private static List<UserInfo> MockUserListResponse()
        {
            byte[] passwordHash, passwordSalt;
            SecurePasswordHasherHelper.CreatePasswordHash("test@123", out passwordHash, out passwordSalt);

            var userAdmin = new UserInfo("Admin", "Admin", "Male", 1234567891, new DateTime(1992, 05, 27), "admin@test.com", passwordHash, passwordSalt, UserRoleType.Admin, "Active");
            var userCustomer = new UserInfo("Thirumalai", "Vasan", "Male", 1234567891, new DateTime(1992, 05, 27), "thirumalai@test.com", passwordHash, passwordSalt, UserRoleType.Customer, "Active");
            var userEmployee = new UserInfo("Rathish", "R", "Male", 1234567891, new DateTime(1992, 05, 27), "rathish@test.com", passwordHash, passwordSalt, UserRoleType.Employee, "Active");

            var userList = new List<UserInfo>
            {
                userAdmin,
                userCustomer,
                userEmployee
            };

            return userList;
        }
    }
}