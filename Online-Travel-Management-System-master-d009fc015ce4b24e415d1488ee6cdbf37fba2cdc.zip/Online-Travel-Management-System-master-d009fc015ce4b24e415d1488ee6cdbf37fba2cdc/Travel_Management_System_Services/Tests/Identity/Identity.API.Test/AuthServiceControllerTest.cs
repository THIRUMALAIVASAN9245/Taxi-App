﻿namespace Identity.API.Test
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Identity.API.Controllers;
    using Identity.API.Queries.CreateUser;
    using Identity.API.Queries.GetUserInfo;
    using Identity.API.Queries.LoginUser;
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Moq;
    using Xunit;

    public class AuthServiceControllerTest
    {
        private Mock<IMediator> mediatR;

        private Mock<ITokenGenerator> tokenGenerator;

        private AuthServiceController controller;

        [Fact]
        public async Task PostCallsMediatRWithExpectedResult()
        {
            // Arrange
            var userModel = new UserInfoModel { FirstName = "Thirumalai" };
            mediatR = new Mock<IMediator>();
            tokenGenerator = new Mock<ITokenGenerator>();
            mediatR.Setup(m => m.Send(It.IsAny<CreateUserRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(userModel));
            controller = new AuthServiceController(mediatR.Object, tokenGenerator.Object);

            // Act
            var result = await controller.Post(userModel) as CreatedResult;

            // Assert            
            Assert.NotNull(result);
            Assert.Equal(201, result.StatusCode);
            var userDetail = result.Value as UserInfoModel;
            Assert.NotNull(userDetail);
            Assert.Equal("Thirumalai", userDetail.FirstName);
        }

        [Fact]
        public async Task PostCallsMediatRWithExpectedNotFoundResult()
        {
            // Arrange
            var userModel = new UserInfoModel { FirstName = "Thirumalai" };
            mediatR = new Mock<IMediator>();
            tokenGenerator = new Mock<ITokenGenerator>();
            mediatR.Setup(m => m.Send(It.IsAny<CreateUserRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult<UserInfoModel>(null));
            controller = new AuthServiceController(mediatR.Object, tokenGenerator.Object);

            // Act
            var result = await controller.Post(userModel) as ObjectResult;

            // Assert
            mediatR.Verify(m => m.Send(It.IsAny<CreateUserRequest>(), It.IsAny<CancellationToken>()), Times.Once());
            Assert.NotNull(result);
            Assert.Equal(409, result.StatusCode);
        }

        [Fact]
        public async Task GetCallsMediatRWithExpectedResult()
        {
            // Arrange
            var getUserRequestModel = new GetUserRequestModel { CustomerId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2"), EmployeeId = new Guid("b5b6ebd7-8556-441d-5063-08d77952a241") };
            mediatR = new Mock<IMediator>();
            tokenGenerator = new Mock<ITokenGenerator>();
            var GetUserResponseModel = new GetUserResponseModel()
            {
                Customer = new UserInfoModel { FirstName = "Thirumalai" },
                Employee = new UserInfoModel { FirstName = "Vasan" }
            };

            mediatR.Setup(m => m.Send(It.IsAny<GetUserInfoRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(GetUserResponseModel));
            controller = new AuthServiceController(mediatR.Object, tokenGenerator.Object);

            // Act
            var result = await controller.GetUserInfo(getUserRequestModel) as OkObjectResult;

            // Assert            
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
            var userDetail = result.Value as GetUserResponseModel;
            Assert.NotNull(userDetail);
            Assert.NotNull(userDetail.Customer);
        }

        [Fact]
        public async Task LoginCallsMediatRWithExpectedResult()
        {
            // Arrange
            var loginReqModel = new LoginRequestModel { Username = "thirumalai@test.com", Password = "test@123" };
            var userModel = new UserInfoModel { FirstName = "Thirumalai" };
            mediatR = new Mock<IMediator>();
            tokenGenerator = new Mock<ITokenGenerator>();
            tokenGenerator.Setup(m => m.GetJwtTokenLoggedinUser(It.IsAny<UserInfoModel>())).Returns("JwtSecurityTokenHandlerToken");
            mediatR.Setup(m => m.Send(It.IsAny<LoginUserRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(userModel));
            controller = new AuthServiceController(mediatR.Object, tokenGenerator.Object);

            // Act
            var result = await controller.Login(loginReqModel) as OkObjectResult;

            // Assert            
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
            var jwtSecurityToken = result.Value as string;
            Assert.NotNull(jwtSecurityToken);
            Assert.Equal("JwtSecurityTokenHandlerToken", jwtSecurityToken);
        }

        [Fact]
        public async Task LoginCallsMediatRWithExpectedNotFoundResult()
        {
            // Arrange
            var loginReqModel = new LoginRequestModel { Username = "thirumalai@test.com", Password = "test@123" };
            var userModel = new UserInfoModel { FirstName = "Thirumalai" };
            mediatR = new Mock<IMediator>();
            tokenGenerator = new Mock<ITokenGenerator>();
            tokenGenerator.Setup(m => m.GetJwtTokenLoggedinUser(It.IsAny<UserInfoModel>())).Returns("JwtSecurityTokenHandlerToken");
            mediatR.Setup(m => m.Send(It.IsAny<LoginUserRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult<UserInfoModel>(null));
            controller = new AuthServiceController(mediatR.Object, tokenGenerator.Object);

            // Act
            var result = await controller.Login(loginReqModel) as NotFoundObjectResult;

            // Assert
            mediatR.Verify(m => m.Send(It.IsAny<LoginUserRequest>(), It.IsAny<CancellationToken>()), Times.Once());
            Assert.NotNull(result);
            Assert.Equal(404, result.StatusCode);
        }

        private static List<UserInfoModel> MockUserListResponse()
        {
            var userList = new List<UserInfoModel>
            {
                new UserInfoModel
                {
                    FirstName = "Thirumalai",
                    LastName = "Vasan",
                    Gender = "Gender",
                    Email ="thirumalai@test.com",
                    Password = "test@123",
                    ConfirmPassword ="test@123",
                    PhoneNumber = 12345,
                    DateOfBirth = new DateTime(),
                    RoleId = 3,
                    Status = "Active",
                    UserId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2")
                },
                new UserInfoModel
                {

                    FirstName = "Thirumalai",
                    LastName = "Vasan",
                    Gender = "Gender",
                    Email ="thirumalai@test.com",
                    Password = "test@123",
                    ConfirmPassword ="test@123",
                    PhoneNumber = 12345,
                    DateOfBirth = new DateTime(),
                    RoleId = 2,
                    Status = "Active",
                    UserId = new Guid("b5b6ebd7-8556-441d-5063-08d77952a241"),
                    VehicleInfo =
                    {
                        UserId =new Guid("b5b6ebd7-8556-441d-5063-08d77952a241"),
                        VehicleNumber = "test",
                        Insurance = "test",
                        License = "test",
                        Registration = "test",
                        Permit = "test",
                        Description = "test"
                    }
                }
            };

            return userList;
        }
    }
}