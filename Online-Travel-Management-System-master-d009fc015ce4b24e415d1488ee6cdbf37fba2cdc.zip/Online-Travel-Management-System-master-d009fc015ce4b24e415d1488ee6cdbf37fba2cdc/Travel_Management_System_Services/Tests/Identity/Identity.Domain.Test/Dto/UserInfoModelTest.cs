﻿namespace Identity.Domain.Test.Dto
{
    using Identity.Domain.Dto;
    using System;
    using Xunit;

    public class UserInfoModelTest
    {
        private readonly UserInfoModel userInfoModel;

        private const string FirstName = "Thirumalai";
        private const string LastName = "Vasan";
        private const string Gender = "Male";
        private const long PhoneNumber = 1234567890;
        private DateTime DateOfBirth = new DateTime(1992, 05, 27);
        private const string Email = "Thirumalai@test.com";
        private const string Password = "Thirumalai@123";
        private const string ConfirmPassword = "Thirumalai@123";
        private const string Status = "Active";

        public UserInfoModelTest()
        {
            userInfoModel = new UserInfoModel();
        }

        [Fact]
        public void TestSetAndGetFirstName()
        {
            userInfoModel.FirstName = FirstName;

            Assert.Equal(userInfoModel.FirstName, FirstName);
        }

        [Fact]
        public void TestSetAndGetLastName()
        {
            userInfoModel.LastName = LastName;

            Assert.Equal(userInfoModel.LastName, LastName);
        }
    }
}
