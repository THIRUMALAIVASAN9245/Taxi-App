﻿namespace Identity.Domain.Test.Aggregates
{
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using System;
    using System.Text;
    using Xunit;

    public class UserInfoTest
    {
        private readonly UserInfo userInfo;

        private const string FirstName = "Thirumalai";
        private const string LastName = "Vasan";
        private const string Gender = "Male";
        private const long PhoneNumber = 1234567890;
        private DateTime DateOfBirth = new DateTime(1992, 05, 27);
        private const string Email = "Thirumalai@test.com";
        private byte[] Password = Encoding.ASCII.GetBytes("Thirumalai@123");
        private byte[] ConfirmPassword = Encoding.ASCII.GetBytes("Thirumalai@123");
        private const UserRoleType RoleId = UserRoleType.Admin;
        private const string Status = "Active";

        public UserInfoTest()
        {
            userInfo = new UserInfo(FirstName, LastName, Gender, PhoneNumber, DateOfBirth, Email, Password, ConfirmPassword, RoleId, Status);
        }

        [Fact]
        public void TestSetAndGetFirstName()
        {
            Assert.Equal(userInfo.FirstName, FirstName);
        }

        [Fact]
        public void TestSetAndGetLastName()
        {
            Assert.Equal(userInfo.LastName, LastName);
        }

        [Fact]
        public void TestSetAndGetGender()
        {
            Assert.Equal(userInfo.Gender, Gender);
        }

        [Fact]
        public void TestSetAndGetPhoneNumber()
        {
            Assert.Equal(userInfo.PhoneNumber, PhoneNumber);
        }

        [Fact]
        public void TestSetAndGetDateOfBirth()
        {
            Assert.Equal(userInfo.DateOfBirth, DateOfBirth);
        }

        [Fact]
        public void TestSetAndGetEmail()
        {
            Assert.Equal(userInfo.Email, Email);
        }

        [Fact]
        public void TestSetAndGetPassword()
        {
            Assert.Equal(userInfo.PasswordHash, Password);
        }

        [Fact]
        public void TestSetAndGetConfirmPassword()
        {
            Assert.Equal(userInfo.PasswordSalt, ConfirmPassword);
        }

        [Fact]
        public void TestSetAndGetRoleId()
        {
            Assert.Equal(userInfo.RoleId, RoleId);
        }

        [Fact]
        public void TestSetAndGetStatus()
        {
            Assert.Equal(userInfo.Status, Status);
        }
    }
}
