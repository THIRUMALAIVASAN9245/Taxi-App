﻿namespace Identity.Domain.Test.Aggregates
{
    using Identity.Domain.Aggregates.VehicleInfo;
    using System;
    using Xunit;

    public class VehicleInfoTest
    {
        private readonly VehicleInfo vehicleInfo;

        private const string VehicleNumber = "TN78TY7623";
        private const string License = "TN0988TT99";
        private const string Insurance = "Yes";
        private const string Permit = "TamilNadu";
        private const string Registration = "TamilNadu";
        private const string Description = "Test";
        private Guid Id = Guid.NewGuid();

        public VehicleInfoTest()
        {
            vehicleInfo = new VehicleInfo(VehicleNumber, License, Insurance, Permit, Registration, Description);
            vehicleInfo.Id = Id;
        }

        [Fact]
        public void TestSetAndGetVehicleNumber()
        {
            Assert.Equal(vehicleInfo.VehicleNumber, VehicleNumber);
        }

        [Fact]
        public void TestSetAndGetInsurance()
        {
            Assert.Equal(vehicleInfo.Insurance, Insurance);
        }

        [Fact]
        public void TestSetAndGetPermit()
        {
            Assert.Equal(vehicleInfo.Permit, Permit);
        }

        [Fact]
        public void TestSetAndGetRegistration()
        {
            Assert.Equal(vehicleInfo.Registration, Registration);
        }

        [Fact]
        public void TestSetAndGetDescription()
        {
            Assert.Equal(vehicleInfo.Description, Description);
        }

        [Fact]
        public void TestSetAndGetId()
        {
            Assert.Equal(vehicleInfo.Id, Id);
        }
    }
}
