﻿namespace Identity.Domain.Test.Aggregates
{
    using Identity.Domain.Aggregates.UserInfo;
    using Xunit;

    public class UserRoleTest
    {
        private readonly UserRole userRole;

        private const string UserRoleType = "TN78TY7623";

        public UserRoleTest() => userRole = new UserRole(UserRoleType) { Id = 1 };

        [Fact]
        public void TestSetAndGetUserRoleType()
        {
            Assert.NotNull(userRole);
            Assert.Equal(userRole.UserRoleType, UserRoleType);
        }

        [Fact]
        public void TestSetAndGetId()
        {
            Assert.Equal(1, userRole.Id);
        }
    }
}
