﻿namespace Identity.Infrastructure.Test
{
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using Identity.Domain.Aggregates.VehicleInfo;
    using Identity.Domain.Interfaces;
    using Identity.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;
    using Moq;
    using System;
    using Xunit;

    public class UnitTestRepository
    {
        private IRepository repository;

        [Fact]
        public void Test1()
        {
            var context = GetContextWithData();
            var controller = new Repository(context);
            try
            {
                var userId = new Guid("4f62e36b-8e36-4a45-4e29-08d778e70ca2");
                var result = repository.Get<UserInfo>(userId);

                Assert.NotNull(result);
            }
            finally
            {
                context.Dispose();
            }
        }

        private IdentityDbContext GetContextWithData()
        {
            var options = new DbContextOptionsBuilder<IdentityDbContext>()
                              .UseInMemoryDatabase(Guid.NewGuid().ToString())
                              .Options;
            var context = new IdentityDbContext(options);

            var userAdmin = new UserInfo("Admin", "Admin", "Male", 1234567891, new DateTime(1992, 05, 27), "admin@test.com", "test@123", "test@123", UserRoleType.Admin, "Active");
            var userCustomer = new UserInfo("Thirumalai", "Vasan", "Male", 1234567891, new DateTime(1992, 05, 27), "thirumalai@test.com", "test@123", "test@123", UserRoleType.Customer, "Active");
            var userEmployee = new UserInfo("Rathish", "R", "Male", 1234567891, new DateTime(1992, 05, 27), "rathish@test.com", "test@123", "test@123", UserRoleType.Employee, "Active");

            userEmployee.AddVehicleInfo(new VehicleInfo("TN 83 7878", "TN 83 43434343", "Tamil Nadu", "All", "Yes", "NA"));

            var userRole1 = new UserRole(UserRoleType.Admin.ToString());
            var userRole2 = new UserRole(UserRoleType.Employee.ToString());
            var userRole3 = new UserRole(UserRoleType.Customer.ToString());

            context.UserInfo.Add(userAdmin);
            context.UserInfo.Add(userCustomer);
            context.UserInfo.Add(userEmployee);

            context.UserRole.Add(userRole1);
            context.UserRole.Add(userRole2);
            context.UserRole.Add(userRole3);

            context.SaveChanges();

            return context;
        }
    }
}
