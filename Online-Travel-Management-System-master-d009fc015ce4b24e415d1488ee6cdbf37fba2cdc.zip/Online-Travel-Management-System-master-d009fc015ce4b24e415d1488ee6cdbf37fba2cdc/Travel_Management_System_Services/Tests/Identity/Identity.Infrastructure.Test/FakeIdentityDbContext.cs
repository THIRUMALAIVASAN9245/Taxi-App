﻿namespace Identity.Infrastructure.Test
{
    using Identity.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;

    public class FakeIdentityDbContext : IdentityDbContext
    {
        public FakeIdentityDbContext(DbContextOptions<IdentityDbContext> options)
            : base(options)
        {
        }

        public new void OnModelCreating(ModelBuilder optionsBuilder)
        {
            base.OnModelCreating(optionsBuilder);
        }
    }
}
