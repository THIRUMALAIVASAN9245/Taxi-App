﻿namespace Identity.Infrastructure.Test
{
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using Identity.Domain.Interfaces;
    using Identity.Infrastructure;
    using Identity.Infrastructure.Context;
    using Identity.Infrastructure.Helpers;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Xunit;

    public class RepositoryTest
    {
        private IRepository repository;

        private Mock<IdentityDbContext> identityDbContext;

        [Fact]
        public void QueryMethodCallRetrunsExeExpectedResult()
        {
            // Arrange
            identityDbContext = new Mock<IdentityDbContext>();
            identityDbContext.Setup(r => r.Set<UserInfo>()).Returns(GetMockWatchList());
            repository = new Repository(identityDbContext.Object);

            // Act            
            var result = repository.Query<UserInfo>();

            // Assert  
            Assert.NotNull(result);
            Assert.Equal(3, result.ToList().Count);
        }

        [Fact]
        public void GetMethodCallRetrunsExeExpectedResult()
        {
            // Arrange
            byte[] passwordHash, passwordSalt;
            SecurePasswordHasherHelper.CreatePasswordHash("test@123", out passwordHash, out passwordSalt);

            var mockUserInfo = new UserInfo("Admin", "Admin", "Male", 1234567891, new DateTime(1992, 05, 27), "admin@test.com", passwordHash, passwordSalt, UserRoleType.Admin, "Active");
            var userId = new Guid("4f62e36b-8e36-4a45-4e29-08d778e70ca2");
            mockUserInfo.UserId = userId;
            var movieCruiserDbContext = new Mock<IdentityDbContext>();
            var dbSetMock = new Mock<DbSet<UserInfo>>();

            movieCruiserDbContext.Setup(x => x.Set<UserInfo>()).Returns(dbSetMock.Object);
            dbSetMock.Setup(x => x.Find(It.IsAny<Guid>())).Returns(mockUserInfo);
            repository = new Repository(movieCruiserDbContext.Object);

            // Act            
            var result = repository.Get<UserInfo>(userId);

            // Assert  
            movieCruiserDbContext.Verify(x => x.Set<UserInfo>());
            dbSetMock.Verify(x => x.Find(It.IsAny<Guid>()));
            Assert.Equal("Admin", result.FirstName);
        }

        private static DbSet<UserInfo> GetMockWatchList()
        {
            byte[] passwordHash, passwordSalt;
            SecurePasswordHasherHelper.CreatePasswordHash("test@123", out passwordHash, out passwordSalt);

            var userAdmin = new UserInfo("Admin", "Admin", "Male", 1234567891, new DateTime(1992, 05, 27), "admin@test.com", passwordHash, passwordSalt, UserRoleType.Admin, "Active");
            var userCustomer = new UserInfo("Thirumalai", "Vasan", "Male", 1234567891, new DateTime(1992, 05, 27), "thirumalai@test.com", passwordHash, passwordSalt, UserRoleType.Customer, "Active");
            var userEmployee = new UserInfo("Rathish", "R", "Male", 1234567891, new DateTime(1992, 05, 27), "rathish@test.com", passwordHash, passwordSalt, UserRoleType.Employee, "Active");

            userAdmin.UserId = new Guid("4f62e36b-8e36-4a45-4e29-08d778e70ca2");
            userCustomer.UserId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2");
            userEmployee.UserId = new Guid("b5b6ebd7-8556-441d-5063-08d77952a241");

            var userList = new List<UserInfo>
            {
                userAdmin,
                userCustomer,
                userEmployee
            };

            DbSet<UserInfo> mockUserInfoList = GetQueryableMockDbSet(userList);

            return mockUserInfoList;
        }

        private static DbSet<T> GetQueryableMockDbSet<T>(List<T> sourceList) where T : class
        {
            var queryable = sourceList.AsQueryable();

            var dbSet = new Mock<DbSet<T>>();
            dbSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(queryable.Provider);
            dbSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(queryable.Expression);
            dbSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
            dbSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(() => queryable.GetEnumerator());

            return dbSet.Object;
        }
    }
}
