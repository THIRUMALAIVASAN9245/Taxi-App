﻿namespace Identity.Infrastructure.Test
{
    using Identity.Domain.Dto;
    using Identity.Domain.Interfaces;
    using Identity.Infrastructure;
    using System;
    using Xunit;

    public class TokenGeneratorTest
    {
        private readonly ITokenGenerator tokenGenerator;        

        public TokenGeneratorTest()
        {
            tokenGenerator = new TokenGenerator();
        }

        [Fact]
        public void GetJwtTokenLoggedinUserWithUserIdReturnsExpectedResult()
        {
            //Arrange            
            var userDetailModel = new UserInfoModel
            {
                UserId = Guid.NewGuid(),
                FirstName = "Thiru",
                LastName = "Vasan",
                Email = "Thiru@test.com",
                RoleId = 1
            };

            //Act
            var actual = tokenGenerator.GetJwtTokenLoggedinUser(userDetailModel);

            //Assert                        
            Assert.NotEmpty(actual);
        }
    }
}
