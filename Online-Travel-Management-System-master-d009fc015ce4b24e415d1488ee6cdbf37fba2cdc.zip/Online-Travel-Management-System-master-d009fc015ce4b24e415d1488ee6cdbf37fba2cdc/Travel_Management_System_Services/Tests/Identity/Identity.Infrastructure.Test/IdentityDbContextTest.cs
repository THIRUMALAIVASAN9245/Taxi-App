﻿namespace Identity.Infrastructure.Test
{
    using Identity.Domain.Aggregates.UserInfo;
    using Identity.Domain.Aggregates.UserInfo.ValueObjects;
    using Identity.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using Microsoft.EntityFrameworkCore.Metadata.Internal;
    using System;
    using System.Linq;
    using Xunit;

    public class IdentityDbContextTest
    {
        //[Fact]
        //public void IdentityDbContextTestOptionsBuilder()
        //{
        //    var options = new DbContextOptions<IdentityDbContext>();
        //    var userAdmin = new UserInfo("Admin", "Admin", "Male", 1234567891, new DateTime(1992, 05, 27), "admin@test.com", "test@123", "test@123", UserRoleType.Admin, "Active");
        //    var builder = new ModelBuilder(userAdmin);

        //    var context = new FakeIdentityDbContext(options);

        //    context.OnModelCreating(builder);
        //}

        [Fact]
        public void OnModelCreatingTest()
        {
            // Arrange
            DbContextOptionsBuilder<IdentityDbContext> builder = new DbContextOptionsBuilder<IdentityDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString());
            var context = new FakeIdentityDbContext(builder.Options);

            // Act
            // hit the entities to force the model to build
            var testEntity = context.UserInfo.FirstOrDefault();
            // use reflection to dig into EF internals
            var builderProperty = typeof(EntityTypeBuilder).GetProperty(
                "Builder",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);

            // Assert
            // validate that the extra ExampleEntity fields are ignored in EF (based on their data annotation)
            context.ModelBuilder.Entity(
              typeof(UserInfo),
              b =>
              {
                  InternalEntityTypeBuilder baseBuilder = (InternalEntityTypeBuilder)builderProperty.GetValue(b);
                  Assert.True(baseBuilder.IsIgnored("Property1", ConfigurationSource.Convention));
                  Assert.True(baseBuilder.IsIgnored("Property2", ConfigurationSource.Convention));
              });
        }
    }
}
