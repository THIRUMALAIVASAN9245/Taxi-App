﻿namespace Booking.Domain.Test.Dto
{
    using Booking.Domain.Dto;
    using System;
    using Xunit;

    public class BookingTest
    {
        private readonly Booking bookingModel;

        private const string BookingId = "BOOK1234";
        private const string CustomerId = "4f62e36b-8e36-4a45-4e29-08d778e70ca2";
        private const string EmployeeId = "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2";
        private const string PickupLocation = "Bangalore";
        private const string DropLocation = "Channai";
        private DateTime PickupDate = new DateTime(2019, 5, 27);
        private const string PickupTime = "12 PM";
        private const string Amount = "1200";
        private const string Status = "Completed";

        public BookingTest()
        {
            bookingModel = new Booking();
        }

        [Fact]
        public void TestSetAndGetBookingId()
        {
            bookingModel.BookingId = BookingId;

            Assert.Equal(bookingModel.BookingId, BookingId);
        }

        [Fact]
        public void TestSetAndGetCustomerId()
        {
            bookingModel.CustomerId = CustomerId;

            Assert.Equal(bookingModel.CustomerId, CustomerId);
        }

        [Fact]
        public void TestSetAndGetEmployeeId()
        {
            bookingModel.EmployeeId = EmployeeId;

            Assert.Equal(bookingModel.EmployeeId, EmployeeId);
        }

        [Fact]
        public void TestSetAndGetPickupLocation()
        {
            bookingModel.PickupLocation = PickupLocation;

            Assert.Equal(bookingModel.PickupLocation, PickupLocation);
        }

        [Fact]
        public void TestSetAndGetDropLocation()
        {
            bookingModel.DropLocation = DropLocation;

            Assert.Equal(bookingModel.DropLocation, DropLocation);
        }

        [Fact]
        public void TestSetAndGetPickupDate()
        {
            bookingModel.PickupDate = PickupDate;

            Assert.Equal(bookingModel.PickupDate, PickupDate);
        }

        [Fact]
        public void TestSetAndGetPickupTime()
        {
            bookingModel.PickupTime = PickupTime;

            Assert.Equal(bookingModel.PickupTime, PickupTime);
        }

        [Fact]
        public void TestSetAndGetAmount()
        {
            bookingModel.Amount = Amount;

            Assert.Equal(bookingModel.Amount, Amount);
        }

        [Fact]
        public void TestSetAndGetStatus()
        {
            bookingModel.Status = Status;

            Assert.Equal(bookingModel.Status, Status);
        }
    }
}
