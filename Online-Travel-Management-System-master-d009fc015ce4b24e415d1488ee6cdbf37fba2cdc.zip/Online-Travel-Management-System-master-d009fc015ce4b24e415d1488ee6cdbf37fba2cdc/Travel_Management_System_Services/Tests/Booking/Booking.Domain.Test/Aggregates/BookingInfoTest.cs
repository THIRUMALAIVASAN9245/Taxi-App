﻿namespace Booking.Domain.Test.Aggregates
{
    using Booking.Domain.Aggregates.BookingInfo;
    using System;
    using Xunit;

    public class BookingInfoTest
    {
        private readonly BookingInfo bookingInfo;

        private const string BookingId = "BOOK1234";
        private const string CustomerId = "4f62e36b-8e36-4a45-4e29-08d778e70ca2";
        private const string EmployeeId = "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2";
        private const string PickupLocation = "Bangalore";
        private const string DropLocation = "Channai";
        private DateTime PickupDate = new DateTime(2019, 5, 27);
        private const string PickupTime = "12 PM";
        private const string Amount = "1200";
        private const string Status = "Completed";
        private Guid Id = Guid.NewGuid();

        public BookingInfoTest()
        {
            bookingInfo = new BookingInfo(BookingId, CustomerId, EmployeeId, PickupLocation, DropLocation, PickupDate, PickupTime, Amount, Status);
            bookingInfo.Id = Id;
        }

        [Fact]
        public void TestSetAndGetBookingId()
        {
            Assert.Equal(bookingInfo.BookingId, BookingId);
        }

        [Fact]
        public void TestSetAndGetCustomerId()
        {
            Assert.Equal(bookingInfo.CustomerId, CustomerId);
        }

        [Fact]
        public void TestSetAndGetEmployeeId()
        {
            Assert.Equal(bookingInfo.EmployeeId, EmployeeId);
        }

        [Fact]
        public void TestSetAndGetPickupLocation()
        {
            Assert.Equal(bookingInfo.PickupLocation, PickupLocation);
        }

        [Fact]
        public void TestSetAndGetDropLocation()
        {
            Assert.Equal(bookingInfo.DropLocation, DropLocation);
        }

        [Fact]
        public void TestSetAndGetPickupDate()
        {
            Assert.Equal(bookingInfo.PickupDate, PickupDate);
        }

        [Fact]
        public void TestSetAndGetPickupTime()
        {
            Assert.Equal(bookingInfo.PickupTime, PickupTime);
        }

        [Fact]
        public void TestSetAndGetAmount()
        {
            Assert.Equal(bookingInfo.Amount, Amount);
        }

        [Fact]
        public void TestSetAndGetStatus()
        {
            Assert.Equal(bookingInfo.Status, Status);
        }

        [Fact]
        public void TestSetAndGetId()
        {
            Assert.Equal(bookingInfo.Id, Id);
        }
    }
}
