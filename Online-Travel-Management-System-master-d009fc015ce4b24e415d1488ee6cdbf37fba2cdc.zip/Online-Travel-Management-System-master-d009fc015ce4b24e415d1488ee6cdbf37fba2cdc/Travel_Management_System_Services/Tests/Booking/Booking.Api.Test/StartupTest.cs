﻿namespace Identity.API.Test
{
    using Xunit;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Moq;
    using Booking.Api.Controllers;
    using Booking.Api;

    public class StartupTest
    {
        [Fact]
        public void ConfigureServicesAsExpected()
        {
            // Arrange
            Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
            Mock<IConfigurationSection> configurationSectionStub = new Mock<IConfigurationSection>();

            configurationSectionStub.Setup(x => x["secret"]).Returns("testSecret");
            configurationSectionStub.Setup(x => x["issuer"]).Returns("testIssuer");
            configurationSectionStub.Setup(x => x["audience"]).Returns("testAudience");
            configurationStub.Setup(x => x.GetSection("Audience")).Returns(configurationSectionStub.Object);

            configurationSectionStub.Setup(x => x["DefaultConnection"]).Returns("DefaultConnectionString");
            configurationStub.Setup(x => x.GetSection("ConnectionStrings")).Returns(configurationSectionStub.Object);

            IServiceCollection services = new ServiceCollection();
            Startup startup = new Startup(configurationStub.Object);

            //  Act
            startup.ConfigureServices(services);
            services.AddTransient<BookingController>();

            //  Assert
            ServiceProvider serviceProvider = services.BuildServiceProvider();
            var controller = serviceProvider.GetService<BookingController>();
            Assert.NotNull(controller);
        }

        //[Fact]
        //public void Should_Redirect_Permanently()
        //{
        //    // Arrange
        //    Mock<IConfiguration> configurationStub = new Mock<IConfiguration>();
        //    Startup startup = new Startup(configurationStub.Object);

        //    hostingEnvironment = new Mock<IHostingEnvironment>();
        //    applicationBuilder = new Mock<IApplicationBuilder>();

        //    applicationBuilder.Setup(x => x.UseMvc()).Returns(applicationBuilder.Object);

        //    //  Act
        //    startup.Configure(applicationBuilder.Object, hostingEnvironment.Object);
        //}
    }
}
