namespace Identity.API.Test.Queries
{
    using AutoMapper;
    using Booking.Api.Queries.CreateBooking;
    using Booking.Domain.Aggregates.BookingInfo;
    using Booking.Domain.Dto;
    using Booking.Domain.Interfaces;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Xunit;

    public class CreateBookingTest
    {
        private CreateBookingRequest request;

        private CreateBooking underTest;

        private Mock<IRepository> repository;

        [Fact]
        public async Task HandleWithValidCreateRequestCallSaveAsExpectedResultAsync()
        {
            // Arrange
            var bookingModel = new Booking { BookingId = "Book123" };
            var config = new MapperConfiguration(m => { m.CreateMap<Booking, BookingInfo>(); m.CreateMap<BookingInfo, Booking>(); });
            var mapper = new Mapper(config);
            var bookingList = MockBookingListResponse().ToList().AsQueryable();

            repository = new Mock<IRepository>();
            repository.Setup(m => m.Save(bookingModel))
              .Returns(bookingList.AsQueryable().FirstOrDefault());

            underTest = new CreateBooking(repository.Object, mapper);
            request = new CreateBookingRequest(bookingModel);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
            Assert.NotNull(result.BookingId);
        }

        private static List<Booking> MockBookingListResponse()
        {
            var bookingList = new List<Booking>
            {
                new Booking
                {
                     BookingId = "Book123",
                     CustomerId = "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2",
                     EmployeeId = "4f62e36b-8e36-4a45-4e29-08d778e70ca2",
                     PickupLocation = "Chennai",
                     PickupDate = new DateTime(2019,10,10),
                     PickupTime = "11 PM",
                     Amount = "100",
                     Status= "Completed",
                     DropLocation="Bangalore",
                     Id = Guid.NewGuid()
                },
                new Booking
                {
                    BookingId = "Book322",
                     CustomerId = "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2",
                     EmployeeId = "4f62e36b-8e36-4a45-4e29-08d778e70ca2",
                     PickupLocation = "Chennai",
                     PickupDate = new DateTime(2019,10,10),
                     PickupTime = "11 PM",
                     Amount = "100",
                     Status= "Completed",
                     DropLocation="Bangalore",
                     Id = Guid.NewGuid()
                }
            };

            return bookingList;
        }
    }
}