namespace Identity.API.Test.Queries
{
    using AutoMapper;
    using Booking.Api.Queries.UpdateBooking;
    using Booking.Domain.Aggregates.BookingInfo;
    using Booking.Domain.Dto;
    using Booking.Domain.Interfaces;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Xunit;

    public class UpdateBookingTest
    {
        private UpdateBookingRequest request;

        private UpdateBooking underTest;

        private Mock<IRepository> repository;

        [Fact]
        public async Task HandleWithValidUpdateBookingCallSaveAsExpectedResultAsync()
        {
            // Arrange
            var bookingModel = new Booking { Id = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2"), BookingId = "Book123" };
            var config = new MapperConfiguration(m => { m.CreateMap<Booking, BookingInfo>(); m.CreateMap<BookingInfo, Booking>(); });
            var mapper = new Mapper(config);
            var bookingList = MockBookingListResponse().ToList().AsQueryable();

            repository = new Mock<IRepository>();
            repository.Setup(m => m.Update(bookingModel))
              .Returns(bookingList.AsQueryable().FirstOrDefault());
            repository.Setup(m => m.Get<BookingInfo>(It.IsAny<Guid>())).Returns(MockBookingInfoResponse());

            underTest = new UpdateBooking(repository.Object, mapper);
            request = new UpdateBookingRequest(bookingModel);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
            Assert.NotNull(result.BookingId);
        }

        [Fact]
        public async Task HandleWithNullUpdateBookingCallSaveAsExpectedResultAsync()
        {
            // Arrange
            var bookingModel = new Booking { Id = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2"), BookingId = "Book123" };
            var config = new MapperConfiguration(m => { m.CreateMap<Booking, BookingInfo>(); m.CreateMap<BookingInfo, Booking>(); });
            var mapper = new Mapper(config);
            repository = new Mock<IRepository>();
            var bookingInfoResponse = MockBookingInfo().FirstOrDefault(x => x.BookingId == "123");
            repository.Setup(m => m.Get<BookingInfo>(It.IsAny<Guid>())).Returns(bookingInfoResponse);

            underTest = new UpdateBooking(repository.Object, mapper);
            request = new UpdateBookingRequest(bookingModel);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.Null(result);
        }

        private static List<BookingInfo> MockBookingInfo()
        {
            var bookingInfo1 = new BookingInfo("Book123", "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2", "4f62e36b-8e36-4a45-4e29-08d778e70ca2", "chennai", "bangalore", new DateTime(2019, 05, 27), "12 PM", "100", "Completed");
            var bookingInfo2 = new BookingInfo("BOOK332", "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2", "4f62e36b-8e36-4a45-4e29-08d778e70ca2", "chennai", "bangalore", new DateTime(2019, 05, 27), "12 PM", "100", "Completed");

            var bookingList = new List<BookingInfo>
            {
                bookingInfo1,
                bookingInfo2
            };

            return bookingList;
        }

        private static BookingInfo MockBookingInfoResponse()
        {
            return new BookingInfo("BOOK332", "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2", "4f62e36b-8e36-4a45-4e29-08d778e70ca2", "chennai", "bangalore", new DateTime(2019, 05, 27), "12 PM", "100", "Completed");
        }

        private static List<Booking> MockBookingListResponse()
        {
            var bookingList = new List<Booking>
            {
                new Booking
                {
                     BookingId = "Book123",
                     CustomerId = "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2",
                     EmployeeId = "4f62e36b-8e36-4a45-4e29-08d778e70ca2",
                     PickupLocation = "Chennai",
                     PickupDate = new DateTime(2019,10,10),
                     PickupTime = "11 PM",
                     Amount = "100",
                     Status= "Completed",
                     DropLocation="Bangalore",
                     Id = new Guid("4f62e36b-8e36-4a45-4e29-08d778e70ca2")
                },
                new Booking
                {
                    BookingId = "Book322",
                     CustomerId = "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2",
                     EmployeeId = "4f62e36b-8e36-4a45-4e29-08d778e70ca2",
                     PickupLocation = "Chennai",
                     PickupDate = new DateTime(2019,10,10),
                     PickupTime = "11 PM",
                     Amount = "100",
                     Status= "Completed",
                     DropLocation="Bangalore",
                     Id = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2")
                }
            };

            return bookingList;
        }
    }
}