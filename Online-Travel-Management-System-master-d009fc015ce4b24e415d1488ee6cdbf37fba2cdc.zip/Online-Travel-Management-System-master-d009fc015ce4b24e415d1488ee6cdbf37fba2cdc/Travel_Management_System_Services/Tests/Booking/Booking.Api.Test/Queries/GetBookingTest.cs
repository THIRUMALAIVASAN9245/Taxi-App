namespace Identity.API.Test.Queries
{
    using AutoMapper;
    using Booking.Api.Queries.GetBooking;
    using Booking.Domain.Aggregates.BookingInfo;
    using Booking.Domain.Dto;
    using Booking.Domain.Interfaces;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Xunit;

    public class GetBookingTest
    {
        private GetBookingRequest request;

        private GetBooking underTest;

        private Mock<IRepository> repository;

        [Fact]
        public async Task HandleWithValidGetBookingRequestCallAdmineAsExpectedResultAsync()
        {
            // Arrange                    
            var getUserRequest = new BookingRequest { CurrentPage = 1, PageSize = 10, IdentityModel = new IdentityModel { RoleId = 1, UserId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2") } };
            var config = new MapperConfiguration(m => { m.CreateMap<BookingInfo, Booking>(); m.CreateMap<Booking, BookingInfo>(); });
            var mapper = new Mapper(config);
            var userDetail = MockBookingListResponse().ToList().AsQueryable();
            repository = new Mock<IRepository>();
            repository.Setup(m => m.Query<BookingInfo>()).Returns(userDetail);

            underTest = new GetBooking(repository.Object, mapper);
            request = new GetBookingRequest(getUserRequest);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Equal(2, result.BookingDetails.Count);
        }


        [Fact]
        public async Task HandleWithValidGetBookingRequestCallEmployeeAsExpectedResultAsync()
        {
            // Arrange                    
            var getUserRequest = new BookingRequest { CurrentPage = 1, PageSize = 10, IdentityModel = new IdentityModel { RoleId = 2, UserId = new Guid("4f62e36b-8e36-4a45-4e29-08d778e70ca2") } };
            var config = new MapperConfiguration(m => { m.CreateMap<BookingInfo, Booking>(); m.CreateMap<Booking, BookingInfo>(); });
            var mapper = new Mapper(config);
            var userDetail = MockBookingListResponse().ToList().AsQueryable();
            repository = new Mock<IRepository>();
            repository.Setup(m => m.Query<BookingInfo>()).Returns(userDetail);

            underTest = new GetBooking(repository.Object, mapper);
            request = new GetBookingRequest(getUserRequest);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Equal(2, result.BookingDetails.Count);
        }


        [Fact]
        public async Task HandleWithValidGetBookingRequestCallCustomerAsExpectedResultAsync()
        {
            // Arrange                    
            var getUserRequest = new BookingRequest { CurrentPage = 1, PageSize = 10, IdentityModel = new IdentityModel { RoleId = 3, UserId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2") } };
            var config = new MapperConfiguration(m => { m.CreateMap<BookingInfo, Booking>(); m.CreateMap<Booking, BookingInfo>(); });
            var mapper = new Mapper(config);
            var userDetail = MockBookingListResponse().ToList().AsQueryable();
            repository = new Mock<IRepository>();
            repository.Setup(m => m.Query<BookingInfo>()).Returns(userDetail);

            underTest = new GetBooking(repository.Object, mapper);
            request = new GetBookingRequest(getUserRequest);

            // Act
            CancellationToken cancellationToken;
            var result = await underTest.Handle(request, cancellationToken);

            // Assert  
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Equal(2, result.BookingDetails.Count);
        }

        private static List<BookingInfo> MockBookingListResponse()
        {
            var bookingInfo1 = new BookingInfo("Book123", "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2", "4f62e36b-8e36-4a45-4e29-08d778e70ca2", "chennai", "bangalore", new DateTime(2019, 05, 27), "12 PM", "100", "Completed");
            var bookingInfo2 = new BookingInfo("BOOK332", "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2", "4f62e36b-8e36-4a45-4e29-08d778e70ca2", "chennai", "bangalore", new DateTime(2019, 05, 27), "12 PM", "100", "Completed");

            var bookingList = new List<BookingInfo>
            {
                bookingInfo1,
                bookingInfo2
            };

            return bookingList;
        }
    }
}