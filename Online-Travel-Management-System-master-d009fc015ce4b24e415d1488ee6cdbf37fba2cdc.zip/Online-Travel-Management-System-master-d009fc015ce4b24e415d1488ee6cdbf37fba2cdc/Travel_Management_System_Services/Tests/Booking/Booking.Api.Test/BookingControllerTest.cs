﻿namespace Identity.API.Test
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Booking.Api.Controllers;
    using Booking.Api.Infrastructure;
    using Booking.Api.Queries.CreateBooking;
    using Booking.Api.Queries.GetBooking;
    using Booking.Api.Queries.UpdateBooking;
    using Booking.Domain.Dto;
    using MediatR;
    using Microsoft.AspNetCore.Mvc;
    using Moq;
    using Xunit;

    public class BookingControllerTest
    {
        private Mock<IMediator> mediatR;

        private Mock<IIdentityService> identityService;

        private BookingController controller;

        [Fact]
        public async Task PostCallsMediatRWithExpectedResult()
        {
            // Arrange
            Booking booking = GetBookingModel();
            IdentityModel identityModel = GetIdentityModel();
            mediatR = new Mock<IMediator>();
            identityService = new Mock<IIdentityService>();
            identityService.Setup(m => m.GetIdentity()).Returns(identityModel);
            mediatR.Setup(m => m.Send(It.IsAny<CreateBookingRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(booking));
            controller = new BookingController(mediatR.Object, identityService.Object);

            // Act
            var result = await controller.Post(booking) as CreatedResult;

            // Assert         
            mediatR.Verify(m => m.Send(It.IsAny<CreateBookingRequest>(), It.IsAny<CancellationToken>()), Times.Once());
            Assert.NotNull(result);
            Assert.Equal(201, result.StatusCode);
        }

        [Fact]
        public async Task PostCallsMediatRWithNullExpectedResult()
        {
            // Arrange
            Booking booking = GetBookingModel();
            IdentityModel identityModel = GetIdentityModel();
            mediatR = new Mock<IMediator>();
            identityService = new Mock<IIdentityService>();
            identityService.Setup(m => m.GetIdentity()).Returns(identityModel);
            mediatR.Setup(m => m.Send(It.IsAny<CreateBookingRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult<Booking>(null));
            controller = new BookingController(mediatR.Object, identityService.Object);

            // Act
            var result = await controller.Post(booking) as ObjectResult;

            // Assert   
            mediatR.Verify(m => m.Send(It.IsAny<CreateBookingRequest>(), It.IsAny<CancellationToken>()), Times.Once());
            Assert.NotNull(result);
            Assert.Equal(409, result.StatusCode);
        }

        [Fact]
        public async Task GetCallsMediatRWithExpectedResult()
        {
            // Arrange
            var bookingModelRequest = GetBookingRequest();
            identityService = new Mock<IIdentityService>();
            IdentityModel identityModel = GetIdentityModel();
            identityService.Setup(m => m.GetIdentity()).Returns(identityModel);
            mediatR = new Mock<IMediator>();
            mediatR.Setup(m => m.Send(It.IsAny<GetBookingRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(GetBookingResponse()));
            controller = new BookingController(mediatR.Object, identityService.Object);

            // Act
            var result = await controller.GetBooking(bookingModelRequest) as OkObjectResult;

            // Assert            
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
            var bookingResponse = result.Value as BookingResponse;
            Assert.NotNull(bookingResponse);
            Assert.Equal(1, bookingResponse.Count);
        }

        [Fact]
        public async Task GetCallsMediatRWithNullExpectedResult()
        {
            // Arrange
            var bookingModelRequest = GetBookingRequest();
            identityService = new Mock<IIdentityService>();
            IdentityModel identityModel = GetIdentityModel();
            identityService.Setup(m => m.GetIdentity()).Returns(identityModel);
            mediatR = new Mock<IMediator>();
            mediatR.Setup(m => m.Send(It.IsAny<GetBookingRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult<BookingResponse>(null));
            controller = new BookingController(mediatR.Object, identityService.Object);

            // Act
            var result = await controller.GetBooking(bookingModelRequest) as ObjectResult;

            // Assert            
            Assert.NotNull(result);
            Assert.Equal(404, result.StatusCode);
        }

        [Fact]
        public async Task PutCallsWithUpdateBookingRequestExpectedResult()
        {
            // Arrange
            var booking = GetBookingModel();
            var bookingModelRequest = GetBookingRequest();
            identityService = new Mock<IIdentityService>();
            IdentityModel identityModel = GetIdentityModel();
            identityService.Setup(m => m.GetIdentity()).Returns(identityModel);
            mediatR = new Mock<IMediator>();
            mediatR.Setup(m => m.Send(It.IsAny<UpdateBookingRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(booking));
            controller = new BookingController(mediatR.Object, identityService.Object);

            // Act
            var result = await controller.Put(booking) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public async Task PutCallsWithUpdateBookingRequestAsNullExpectedResult()
        {
            // Arrange
            var booking = GetBookingModel();
            var bookingModelRequest = GetBookingRequest();
            identityService = new Mock<IIdentityService>();
            IdentityModel identityModel = GetIdentityModel();
            identityService.Setup(m => m.GetIdentity()).Returns(identityModel);
            mediatR = new Mock<IMediator>();
            mediatR.Setup(m => m.Send(It.IsAny<UpdateBookingRequest>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult<Booking>(null));
            controller = new BookingController(mediatR.Object, identityService.Object);

            // Act
            var result = await controller.Put(booking) as ObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(409, result.StatusCode);
        }

        private static BookingResponse GetBookingResponse()
        {
            return new BookingResponse { BookingDetails = new List<Booking> { GetBookingModel() }, Count = 1 };
        }

        private static BookingRequest GetBookingRequest()
        {
            return new BookingRequest { CurrentPage = 1, PageSize = 10 };
        }

        private static IdentityModel GetIdentityModel()
        {
            return new IdentityModel { RoleId = 1, UserId = new Guid("ffdbc542-3eb5-4f93-4e2a-08d778e70ca2") };
        }

        private static Booking GetBookingModel()
        {
            return new Booking
            {
                BookingId = "Book123",
                CustomerId = "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2",
                EmployeeId = "4f62e36b-8e36-4a45-4e29-08d778e70ca2",
                PickupLocation = "Chennai",
                PickupDate = new DateTime(2019, 10, 10),
                PickupTime = "11 PM",
                Amount = "100",
                Status = "Completed",
                DropLocation = "Bangalore",
                Id = Guid.NewGuid()
            };
        }
    }
}