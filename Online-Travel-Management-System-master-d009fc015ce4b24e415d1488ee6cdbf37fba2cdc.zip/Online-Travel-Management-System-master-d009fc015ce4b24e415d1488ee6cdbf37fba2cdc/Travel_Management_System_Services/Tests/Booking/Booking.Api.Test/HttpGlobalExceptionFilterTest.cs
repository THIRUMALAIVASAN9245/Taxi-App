﻿namespace Identity.API.Test
{
    using Booking.Api.Infrastructure.Filters;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Abstractions;
    using Microsoft.AspNetCore.Mvc.Filters;
    using Microsoft.AspNetCore.Routing;
    using Microsoft.Extensions.Logging;
    using Moq;
    using System;
    using System.Collections.Generic;
    using Xunit;

    public class HttpGlobalExceptionFilterTest
    {
        private HttpGlobalExceptionFilter underTest;

        private Mock<IHostingEnvironment> hostingEnvironment;

        private Mock<ILogger<HttpGlobalExceptionFilter>> logHttpGlobalExceptionFilter;

        [Fact]
        public void OnExceptionWithExceptionAsExpected()
        {
            // Arrange                    
            hostingEnvironment = new Mock<IHostingEnvironment>();
            logHttpGlobalExceptionFilter = new Mock<ILogger<HttpGlobalExceptionFilter>>();
            ActionContext actionContext = GetActionContext();

            var exception = new ApplicationException("Test");
            var exceptionContext = new ExceptionContext(actionContext, new List<IFilterMetadata>())
            {
                Exception = exception
            };
            underTest = new HttpGlobalExceptionFilter(hostingEnvironment.Object, logHttpGlobalExceptionFilter.Object);

            // Act
            underTest.OnException(exceptionContext);
        }

        private static ActionContext GetActionContext()
        {
            var httpContext = new DefaultHttpContext();
            httpContext.Request.Method = "GET";
            var routeData = new RouteData();
            routeData.Values.Add("controller", "Controller");
            routeData.Values.Add("action", "Action");
            var actionContext = new ActionContext(httpContext, routeData, new ActionDescriptor());
            return actionContext;
        }
    }
}
