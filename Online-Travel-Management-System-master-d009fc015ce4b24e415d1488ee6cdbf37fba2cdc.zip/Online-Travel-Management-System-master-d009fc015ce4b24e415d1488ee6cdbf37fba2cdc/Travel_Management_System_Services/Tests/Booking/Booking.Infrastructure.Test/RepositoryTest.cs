﻿namespace Booking.Infrastructure.Test
{
    using Booking.Domain.Aggregates.BookingInfo;
    using Booking.Domain.Interfaces;
    using Booking.Infrastructure.Context;
    using Microsoft.EntityFrameworkCore;
    using Moq;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Xunit;

    public class RepositoryTest
    {
        private IRepository repository;

        private Mock<BookingDbContext> bookingDbContext;

        [Fact]
        public void QueryMethodCallRetrunsExeExpectedResult()
        {
            // Arrange
            bookingDbContext = new Mock<BookingDbContext>();
            bookingDbContext.Setup(r => r.Set<BookingInfo>()).Returns(GetMockWatchList());
            repository = new Repository(bookingDbContext.Object);

            // Act            
            var result = repository.Query<BookingInfo>();

            // Assert  
            Assert.NotNull(result);
            Assert.Single(result.ToList());
        }

        [Fact]
        public void GetMethodCallRetrunsExeExpectedResult()
        {
            // Arrange
            var bookingInfo = new BookingInfo("Book123", "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2", "4f62e36b-8e36-4a45-4e29-08d778e70ca2", "chennai", "bangalore", new DateTime(2019, 05, 27), "12 PM", "100", "Completed");
            var bookingDbContext = new Mock<BookingDbContext>();
            var dbSetMock = new Mock<DbSet<BookingInfo>>();

            bookingDbContext.Setup(x => x.Set<BookingInfo>()).Returns(dbSetMock.Object);
            dbSetMock.Setup(x => x.Find(It.IsAny<Guid>())).Returns(bookingInfo);
            repository = new Repository(bookingDbContext.Object);

            // Act            
            var result = repository.Get<BookingInfo>(Guid.NewGuid());

            // Assert  
            bookingDbContext.Verify(x => x.Set<BookingInfo>());
            dbSetMock.Verify(x => x.Find(It.IsAny<Guid>()));
            Assert.Equal("Book123", result.BookingId);
        }

        private static DbSet<BookingInfo> GetMockWatchList()
        {
            var bookingInfo = new BookingInfo("Book123", "ffdbc542-3eb5-4f93-4e2a-08d778e70ca2", "4f62e36b-8e36-4a45-4e29-08d778e70ca2", "chennai", "bangalore", new DateTime(2019, 05, 27), "12 PM", "100", "Completed");
            var bookingList = new List<BookingInfo> { bookingInfo };

            DbSet<BookingInfo> mockBookingInfoList = GetQueryableMockDbSet(bookingList);

            return mockBookingInfoList;
        }

        private static DbSet<T> GetQueryableMockDbSet<T>(List<T> sourceList) where T : class
        {
            var queryable = sourceList.AsQueryable();

            var dbSet = new Mock<DbSet<T>>();
            dbSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(queryable.Provider);
            dbSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(queryable.Expression);
            dbSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
            dbSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(() => queryable.GetEnumerator());

            return dbSet.Object;
        }
    }
}
