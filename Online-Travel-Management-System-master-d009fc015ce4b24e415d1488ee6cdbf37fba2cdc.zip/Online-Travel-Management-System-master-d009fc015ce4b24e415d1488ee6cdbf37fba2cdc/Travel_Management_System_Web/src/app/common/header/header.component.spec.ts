import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/providers/services/auth.service';

import { HeaderComponent } from './header.component';

describe('Header Component Scenarios: ', () => {
    let fixture: ComponentFixture<HeaderComponent>;
    let component: HeaderComponent;
    let mockRouter: Router;
    let mockAuthService: AuthService;

    beforeEach(async(() => {
        // arrange
        mockRouter = jasmine.createSpyObj("router", ["navigate"]);
        mockAuthService = jasmine.createSpyObj("authService", ["login", "deleteToken"]);
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [HeaderComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: AuthService, useValue: mockAuthService },
                { provide: Router, useValue: mockRouter }]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(HeaderComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the header component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("logoutUser function", () => {
        it("should verify logoutUser and navigate to home screen", () => {
            // act
            component.logoutUser();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/auth/login']);
        });
    });
});