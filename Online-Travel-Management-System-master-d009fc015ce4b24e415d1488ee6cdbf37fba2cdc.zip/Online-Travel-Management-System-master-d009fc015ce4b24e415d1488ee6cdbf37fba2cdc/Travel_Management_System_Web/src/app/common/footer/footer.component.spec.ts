import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { FooterComponent } from './footer.component';

describe('Footer Component Scenarios: ', () => {
    let fixture: ComponentFixture<FooterComponent>;
    let component: FooterComponent;

    beforeEach(async(() => {
        // arrange
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [FooterComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: []
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(FooterComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the footer component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });
});