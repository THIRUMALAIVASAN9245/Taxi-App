import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { AuthService } from 'src/app/providers/services/auth.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MustMatch } from './must-match.validator';

@Component({
    selector: 'app-registration',
    templateUrl: './registration.component.html'
})
export class RegistrationComponent implements OnInit {
    myFormGroupFlag: boolean = true;
    registerForm: FormGroup;
    submitted: boolean = false;
    errorMessage: string = "";

    constructor(
        private router: Router,
        private spinnerService: Ng4LoadingSpinnerService,
        private formBuilder: FormBuilder,
        private authService: AuthService) { }

    ngOnInit() {
        this.buildRegisterForm();
    }

    buildRegisterForm() {
        this.registerForm = this.formBuilder.group({
            firstName: ['', [Validators.required]],
            lastName: ['', [Validators.required]],
            gender: ['male', [Validators.required]],
            phoneNumber: ['', [Validators.required]],
            dateOfBirth: ['', [Validators.required]],
            email: ['', [Validators.required, Validators.email]],
            password: ['', [Validators.required, Validators.minLength(6)]],
            confirmPassword: ['', [Validators.required]],
            roleId: ['3', []],
            status: ['Active', []]
        }, {
            validator: MustMatch('password', 'confirmPassword')
        });
        if (!this.myFormGroupFlag) {
            this.registerForm.addControl('vehicleInfo', this.createFormArray());
        }
    }

    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.errorMessage = "";
        this.submitted = true;
        if (this.registerForm.invalid) {
            return;
        }
        this.spinnerService.show();
        const response = this.authService.register(this.registerForm.value);
        response.subscribe(result => {
            this.spinnerService.hide();
            this.router.navigate(['/auth/login']);
        }, error => {
            this.spinnerService.hide();
            this.errorMessage = error.message;
        });
    }

    createFormArray() {
        return this.formBuilder.group({
            vehicleNumber: ['', [Validators.required]],
            license: ['', [Validators.required]],
            insurance: ['', [Validators.required]],
            permit: ['', [Validators.required]],
            registration: ['', [Validators.required]],
            description: ['', [Validators.required]]
        });
    }

    get vehicleInfo(): FormArray {
        return this.registerForm.get("vehicleInfo") as FormArray;
    }

    onChange(value: boolean) {
        this.myFormGroupFlag = value;
        this.submitted = false;
        this.buildRegisterForm();
        const roleId = value ? "3" : "2";
        this.registerForm.patchValue({ roleId: roleId });
    }
}
