import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AuthService } from 'src/app/providers/services/auth.service';

import { RegistrationComponent } from './registration.component';

describe('Registration Component Positive Scenarios: ', () => {
    let fixture: ComponentFixture<RegistrationComponent>;
    let component: RegistrationComponent;
    let mockRouter: Router;
    let mockFormBuilder: FormBuilder;
    let mockNg4LoadingSpinnerService: Ng4LoadingSpinnerService;
    let mockAuthService: AuthService;

    beforeEach(async(() => {
        // arrange
        mockRouter = jasmine.createSpyObj("router", ["navigate"]);
        mockNg4LoadingSpinnerService = jasmine.createSpyObj("mockNg4LoadingSpinnerService", ["show", "hide"]);
        mockAuthService = jasmine.createSpyObj("authService", ["register"]);
        ((mockAuthService.register) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [RegistrationComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: AuthService, useValue: mockAuthService },
                { provide: Router, useValue: mockRouter },
                { provide: Ng4LoadingSpinnerService, useValue: mockNg4LoadingSpinnerService },
                FormBuilder]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(RegistrationComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the register component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("register function", () => {
        beforeEach(() => {
            // act                                     
            component.ngOnInit();
        });

        it("should verify form valid", () => {
            // assert
            expect(component.registerForm.valid).toEqual(false);
        });

        it("should verify register with invalid credentials returns false", () => {
            // act
            component.onSubmit();

            // assert           
            expect(component.registerForm.valid).toEqual(false);
        });

        it("should verify onSubmit with valid userinfo navigate to loign screen", () => {
            // arrange   
            const testUser = {
                firstName: 'thiru',
                lastName: 'vasan',
                email: "thiru@test.com",
                phoneNumber: '123456',
                dateOfBirth: '12-12-2019',
                password: 'password',
                confirmPassword: 'password',
            };

            Object.keys(testUser).forEach(name => {
                if (component.registerForm.controls[name]) {
                    component.registerForm.controls[name].patchValue(testUser[name]);
                }
            });

            // act
            component.onSubmit();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/auth/login']);
        });

        it("should verify formControls", () => {
            // arrange   
            const testUser = {
                firstName: 'thiru',
                lastName: 'vasan'
            };
            component.registerForm.controls['firstName'].setValue(testUser.firstName);
            component.registerForm.controls['lastName'].setValue(testUser.lastName);

            // act
            const response = component.f;

            // assert    
            expect(response).toBeTruthy();
        });

        it("should verify onSubmit with invalid password", () => {
            // arrange   
            const testUser = {
                password: 'passwordd',
                confirmPassword: 'password',
            };

            Object.keys(testUser).forEach(name => {
                if (component.registerForm.controls[name]) {
                    component.registerForm.controls[name].patchValue(testUser[name]);
                }
            });

            // act
            component.onSubmit();

            // assert           
            expect(component.registerForm.controls["confirmPassword"].valid).toBe(false);
        });
    });

    describe("onChange Method", () => {
        it("should call onChange the register component build customer form", () => {
           // act
           component.onChange(true);

           // assert           
           expect(component.registerForm).toBeTruthy();
        });

        it("should call onChange the register component build employee form", () => {
            // act
            component.onChange(false);
 
            // assert           
            expect(component.registerForm).toBeTruthy();
         });

         it("should call onChange the register component build employee form with vehicleInfo", () => {
            // act
            component.onChange(false);
 
            // assert           
            expect(component.vehicleInfo).toBeTruthy();
         });
    });
});

describe('Register Component Negative Scenarios: ', () => {
    let fixture: ComponentFixture<RegistrationComponent>;
    let component: RegistrationComponent;
    let mockRouter: Router;
    let mockFormBuilder: FormBuilder;
    let mockNg4LoadingSpinnerService: Ng4LoadingSpinnerService;
    let mockAuthService: AuthService;

    beforeEach(async(() => {
        // arrange
        mockRouter = jasmine.createSpyObj("router", ["navigate"]);
        mockNg4LoadingSpinnerService = jasmine.createSpyObj("mockNg4LoadingSpinnerService", ["show", "hide"]);
        mockAuthService = jasmine.createSpyObj("authService", ["register"]);
        ((mockAuthService.register) as jasmine.Spy).and.returnValue(throwError(new Error('error')));
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [RegistrationComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: AuthService, useValue: mockAuthService },
                { provide: Router, useValue: mockRouter },
                { provide: Ng4LoadingSpinnerService, useValue: mockNg4LoadingSpinnerService },
                FormBuilder]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(RegistrationComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the register component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("registerUserDetails function", () => {
        beforeEach(() => {
            // act                                     
            component.ngOnInit();
            const testUser = {
                firstName: 'thiru',
                lastName: 'vasan',
                email: "thiru@test.com",
                phoneNumber: '123456',
                dateOfBirth: '12-12-2019',
                password: 'password',
                confirmPassword: 'password',
            };

            Object.keys(testUser).forEach(name => {
                if (component.registerForm.controls[name]) {
                    component.registerForm.controls[name].patchValue(testUser[name]);
                }
            });
        });

        it("should verify registerUserDetails with valid user details returns throw exception", () => {
            // act
            const response = component.f;

            // assert           
            expect(response).toBeTruthy();
        });

        it("should verify register with invalid register returns throw exception", () => {
            // act
            component.onSubmit();

            // assert           
            expect(component.errorMessage).toBe('error');
        });
    });
});