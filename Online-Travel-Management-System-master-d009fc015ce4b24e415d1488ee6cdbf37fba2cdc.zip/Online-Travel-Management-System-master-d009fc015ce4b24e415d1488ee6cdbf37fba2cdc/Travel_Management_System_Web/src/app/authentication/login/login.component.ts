import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './../../providers/services/auth.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isSubmitted = false;
  isErrorMessage: string = "";

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private spinnerService: Ng4LoadingSpinnerService,
    private authService: AuthService) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get formControls() {
    return this.loginForm.controls;
  }

  login() {
    this.isErrorMessage = "";
    this.isSubmitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.spinnerService.show();
    const response = this.authService.login(this.loginForm.value);
    response.subscribe((response) => {
      this.spinnerService.hide();
      this.authService.setToken(JSON.parse(response).token);
      this.router.navigate(['/booking/booking-details']);
    }, error => {
      this.spinnerService.hide();
      this.isErrorMessage = error.message;
    });
  }
}