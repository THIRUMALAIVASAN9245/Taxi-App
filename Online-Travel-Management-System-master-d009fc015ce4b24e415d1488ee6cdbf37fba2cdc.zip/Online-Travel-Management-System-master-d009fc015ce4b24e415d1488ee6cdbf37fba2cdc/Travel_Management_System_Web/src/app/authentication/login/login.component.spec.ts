import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AuthService } from 'src/app/providers/services/auth.service';

import { LoginComponent } from './login.component';

describe('Login Component Positive Scenarios: ', () => {
    let fixture: ComponentFixture<LoginComponent>;
    let component: LoginComponent;
    let mockRouter: Router;
    let mockFormBuilder: FormBuilder;
    let mockNg4LoadingSpinnerService: Ng4LoadingSpinnerService;
    let mockAuthService: AuthService;

    beforeEach(async(() => {
        // arrange
        mockRouter = jasmine.createSpyObj("router", ["navigate"]);
        mockNg4LoadingSpinnerService = jasmine.createSpyObj("mockNg4LoadingSpinnerService", ["show", "hide"]);
        mockAuthService = jasmine.createSpyObj("authService", ["login", "setToken"]);
        ((mockAuthService.login) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [LoginComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: AuthService, useValue: mockAuthService },
                { provide: Router, useValue: mockRouter },
                { provide: Ng4LoadingSpinnerService, useValue: mockNg4LoadingSpinnerService },
                FormBuilder]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(LoginComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the login component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("login function", () => {
        beforeEach(() => {
            // act                                     
            component.ngOnInit();
        });

        it("should verify form valid", () => {
            // assert
            expect(component.loginForm.valid).toEqual(false);
        });

        it("should verify login with invalid credentials returns false", () => {
            // act
            component.login();

            // assert           
            expect(component.loginForm.valid).toEqual(false);
        });

        it("should verify login with valid credentials navigate to home screen", () => {
            // arrange   
            const testUser = {
                username: 'test@test.com',
                password: '12345'
            };
            component.loginForm.controls['username'].setValue(testUser.username);
            component.loginForm.controls['password'].setValue(testUser.password);

            // act
            component.login();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/booking/booking-details']);
        });

        it("should verify formControls", () => {
            // arrange   
            const testUser = {
                username: 'test@test.com',
                password: '12345'
            };
            component.loginForm.controls['username'].setValue(testUser.username);
            component.loginForm.controls['password'].setValue(testUser.password);

            // act
            const response = component.formControls;

            // assert    
            expect(response).toBeTruthy();
        });
    });
});

describe('Login Component Negative Scenarios: ', () => {
    let fixture: ComponentFixture<LoginComponent>;
    let component: LoginComponent;
    let mockRouter: Router;
    let mockFormBuilder: FormBuilder;
    let mockNg4LoadingSpinnerService: Ng4LoadingSpinnerService;
    let mockAuthService: AuthService;

    beforeEach(async(() => {
        // arrange
        mockRouter = jasmine.createSpyObj("router", ["navigate"]);
        mockNg4LoadingSpinnerService = jasmine.createSpyObj("mockNg4LoadingSpinnerService", ["show", "hide"]);
        mockAuthService = jasmine.createSpyObj("authService", ["login", "setToken"]);
        ((mockAuthService.login) as jasmine.Spy).and.returnValue(throwError(new Error('error')));
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [LoginComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [{ provide: AuthService, useValue: mockAuthService },
            { provide: Router, useValue: mockRouter },
            { provide: Ng4LoadingSpinnerService, useValue: mockNg4LoadingSpinnerService },
            FormBuilder]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(LoginComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the login component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("login function", () => {
        beforeEach(() => {
            // act                                     
            component.ngOnInit();
        });

        it("should verify login with valid credentials returns throw exception", () => {
            // arrange   
            const testUser = {
                username: 'test@test.com',
                password: '12345'
            };
            component.loginForm.controls['username'].setValue(testUser.username);
            component.loginForm.controls['password'].setValue(testUser.password);

            // act
            component.login();

            // assert           
            expect(component.isErrorMessage).toBe('error');
        });
    });
});