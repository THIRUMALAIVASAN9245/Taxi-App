import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';

import { AuthComponent } from './auth.component';

describe('AuthComponent Component Scenarios: ', () => {
    let fixture: ComponentFixture<AuthComponent>;
    let component: AuthComponent;
    let mockRouter: any;

    beforeEach(async(() => {
        // arrange
        mockRouter = {
            url: '/login',
            navigate: jasmine.createSpy('navigate')
        }

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [AuthComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: Router, useValue: mockRouter }
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(AuthComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the AuthComponent component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("changeText function", () => {
        it("should verify changeText with buttonTextFlag is true call registration route", () => {
            // arrange
            component.buttonTextFlag = true;

            // act
            component.changeText();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/auth/registration']);
        });

        it("should verify changeText with buttonTextFlag is false call login route", () => {
            // arrange
            component.buttonTextFlag = false;

            // act
            component.changeText();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/auth/login']);
        });
    });
});