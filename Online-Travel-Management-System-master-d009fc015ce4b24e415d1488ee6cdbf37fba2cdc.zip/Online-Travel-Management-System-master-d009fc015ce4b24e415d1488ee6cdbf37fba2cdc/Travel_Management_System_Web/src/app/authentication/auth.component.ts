import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent {
  buttonTextFlag: boolean;

  constructor(private router: Router) {
    this.buttonTextFlag = this.router.url.includes('login') ? true : false;
  }

  changeText(): void {
    if (this.buttonTextFlag === true) {
      this.router.navigate(['/auth/registration']);
      this.buttonTextFlag = false;
    } else {
      this.router.navigate(['/auth/login']);
      this.buttonTextFlag = true;
    }
  }
}
