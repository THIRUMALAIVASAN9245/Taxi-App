import { environment } from '../../../environments/environment.prod';
import { TestBed, inject } from '@angular/core/testing';
import { HttpEvent, HttpEventType, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { of, throwError } from 'rxjs';

import { AuthService } from './auth.service';
import { catchError } from 'rxjs/operators';

describe('DashBoardService', () => {
    let BASE_URL: string = "testUrl";
    let authService: AuthService;
    let mockHttpClient: HttpClient;
    let store = {};

    beforeEach(() => {

        mockHttpClient = jasmine.createSpyObj("HttpClient", ["post", "get"]);
        ((mockHttpClient.post) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));
        ((mockHttpClient.get) as jasmine.Spy).and.returnValue(of('{ "userdetail": "qwerpoiuytr"}'));

        spyOn(localStorage, 'getItem').and.callFake((key: string): string => {
            return store[key] || null;
        });
        spyOn(localStorage, 'removeItem').and.callFake((key: string): void => {
            delete store[key];
        });
        spyOn(localStorage, 'setItem').and.callFake((key: string, value: string): string => {
            return store[key] = <string>value;
        });
        spyOn(localStorage, 'clear').and.callFake(() => {
            store = {};
        });

        spyOn(window, 'atob').and.callFake((): string => {
            return '{"firstname":"Jesper","surname":"Aaberg","phone":["555-0100","555-0120"]}';
        });

        authService = new AuthService(mockHttpClient);
    });

    it("should create the authService", () => {
        // assert
        expect(authService).toBeTruthy();
    });

    it("should set the setToken and getToken", () => {
        // arrange
        authService.setToken("jwt_TokenResponse");

        // assert
        expect(authService.getToken()).toBe("jwt_TokenResponse");
    });

    it("should create the getUserIdentity", () => {
        // arrange
        authService.setToken("jwt_TokenResponseNew");

        // act
        const userIdentity = authService.getUserIdentity();

        // assert
        expect(userIdentity.firstname).toBe("Jesper");
        expect(userIdentity.surname).toBe("Aaberg");
    });

    it("should create the getUserIdentity", () => {
        // arrange
        authService.setToken("jwt_TokenResponseDelete");

        // act
        authService.deleteToken();

        // assert
        expect(authService.getToken()).toBeNull();
    });

    it("should create the isTokenExpired", () => {
        // arrange
        authService.setToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImJkNGE5NDcyLTM1ZjUtNGI4Yi1jOWExLTA4ZDc3NGQ3Y2ZiYSIsImp0aSI6Ijg5ZjgxNGFmLWY5MzYtNDljZS04Y2EyLTQ2YWZjMDVmNjJmYSIsInVzZXJJZCI6ImJkNGE5NDcyLTM1ZjUtNGI4Yi1jOWExLTA4ZDc3NGQ3Y2ZiYSIsImZpcnN0TmFtZSI6IlRoaXJ1bWFsYWkiLCJsYXN0TmFtZSI6IlZhc2FuIiwicm9sZUlkIjoiMiIsImV4cCI6MTU3NTA1NTYzMCwiaXNzIjoiaXNzdWVyVGVzdCIsImF1ZCI6ImF1ZGllbmNlVGVzdCJ9.JRbKGSisps2Kmv85Oq0-hIbUr9RmABiiJE9jFHha5bE");

        // act
        const isTokenExpired = authService.isTokenExpired();

        // assert
        expect(isTokenExpired).toBe(true);
    });

    it("should create the getTokenExpirationDate", () => {
        // arrange
        authService.setToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE1NzUwMzE3NDgsImlzcyI6Imlzc3VlclRlc3QiLCJhdWQiOiJhdWRpZW5jZVRlc3QifQ.AGhx3MGB5YU427wSEJgS1lMQf41rCecZ3iS2qb6eRPA");

        // act
        const getTokenExpirationDate = authService.getTokenExpirationDate();

        // assert
        expect(getTokenExpirationDate).toBeTruthy();
    });

    it("should create the isLoggedIn", () => {
        // arrange
        authService.setToken("jwt_TokenResponseIsLoggedIn");

        // act
        const result = authService.isLoggedIn;

        // assert
        expect(result).toBeTruthy();
    });

    it("should create the login", () => {
        // arrange
        const userDetails = { username: "test", password: "password" };

        // act
        authService.login(userDetails);

        // assert
        expect(mockHttpClient.post).toHaveBeenCalled();
    });

    it("should create the register", () => {
        // arrange
        const userDetails = { username: "test", password: "password" };

        // act
        authService.register(userDetails);

        // assert
        expect(mockHttpClient.post).toHaveBeenCalled();
    });

    it("should create the register", () => {
        // arrange
        const userDetails = { username: "test" };

        // act
        authService.getUserInfo(userDetails);

        // assert
        expect(mockHttpClient.get).toHaveBeenCalled();
    });
});