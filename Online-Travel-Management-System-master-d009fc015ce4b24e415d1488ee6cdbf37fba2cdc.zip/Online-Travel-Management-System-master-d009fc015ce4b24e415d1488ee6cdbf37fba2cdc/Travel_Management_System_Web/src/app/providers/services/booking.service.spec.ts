import { environment } from '../../../environments/environment.prod';
import { TestBed, inject } from '@angular/core/testing';
import { HttpEvent, HttpEventType, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { BookingService } from './booking.service';

describe('DashBoardService', () => {
    let BASE_URL: string = "testUrl";
    let mockBookingService: BookingService;
    let mockHttpClient: HttpClient;

    beforeEach(() => {

        mockHttpClient = jasmine.createSpyObj("HttpClient", ["post", "get", "put"]);
        ((mockHttpClient.post) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));
        ((mockHttpClient.get) as jasmine.Spy).and.returnValue(of('{ "userdetail": "qwerpoiuytr"}'));
        ((mockHttpClient.put) as jasmine.Spy).and.returnValue(of('{ "userdetail": "qwerpoiuytr"}'));

        mockBookingService = new BookingService(mockHttpClient);
    });

    it("should create the authService", () => {
        // assert
        expect(mockBookingService).toBeTruthy();
    });


    it("should create the new bookingDetails", () => {
        // arrange
        const bookingDetails = {
            bookingid: "book1767",
            pickupaddress: "tadwadi, surat, gujarat, india",
            pickupdate: new Date("1990-02-02"),
            dropaddress: "delhi, india",
            dropdate: new Date("1990-02-02"),
            amount: "743",
            paymentstatus: "",
            status: "pending"
        };

        // act
        mockBookingService.booking(bookingDetails);

        // assert
        expect(mockHttpClient.post).toHaveBeenCalled();
    });

    it("should update the booking details", () => {
        // arrange
        const bookingDetails = {
            bookingid: "book1767",
            pickupaddress: "tadwadi, surat, gujarat, india",
            pickupdate: new Date("1990-02-02"),
            dropaddress: "delhi, india",
            dropdate: new Date("1990-02-02"),
            amount: "743",
            paymentstatus: "",
            status: "pending"
        };

        // act
        mockBookingService.updateBooking(bookingDetails);

        // assert
        expect(mockHttpClient.put).toHaveBeenCalled();
    });

    it("should get the Bookings", () => {
        // arrange
        const currentPage = 1;

        // act
        mockBookingService.getBookings(currentPage);

        // assert
        expect(mockHttpClient.get).toHaveBeenCalled();
    });
});