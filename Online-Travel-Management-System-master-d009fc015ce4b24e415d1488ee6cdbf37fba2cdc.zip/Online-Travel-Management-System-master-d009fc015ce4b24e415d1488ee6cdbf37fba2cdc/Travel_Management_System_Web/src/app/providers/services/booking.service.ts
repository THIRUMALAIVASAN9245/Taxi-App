import { Injectable, Optional, Inject, InjectionToken } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export const API_BOOKING_BASEURL = new InjectionToken<string>("API_BOOKING_BASEURL");

@Injectable()
export class BookingService {

  baseUrl;

  constructor(private http: HttpClient, @Optional() @Inject(API_BOOKING_BASEURL) baseUrl?: string) {
    this.baseUrl = baseUrl ? baseUrl = "Booking/" : "http://localhost:63540/booking-api/Booking/";
  }

  booking(bookingData: IBooking): Observable<any> {
    var bodyData = JSON.stringify(bookingData);
    let url = `${this.baseUrl}`;

    return this.http.post(url, bodyData).pipe(catchError(this.handleError('booking')));
  }

  getBookings(currentPage: any): Observable<any> {
    let url = `${this.baseUrl}` + "GetBooking?PageSize=10&CurrentPage=" + currentPage;
    return this.http.get<any>(url).pipe(catchError(this.handleError('GetBooking')));
  }

  updateBooking(bookingData: IBooking): Observable<any> {
    var bodyData = JSON.stringify(bookingData);
    let url = `${this.baseUrl}`;

    return this.http.put(url, bodyData).pipe(catchError(this.handleError('booking')));
  }

  private handleError(operation: string) {
    return (error: any): Observable<any> => {
      console.error(error);
      let errMsg = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'An server error occurred' + operation;
      let errObj = {
        title: errMsg,
        message: error.error
      };
      return throwError(errObj);
    };
  }
}