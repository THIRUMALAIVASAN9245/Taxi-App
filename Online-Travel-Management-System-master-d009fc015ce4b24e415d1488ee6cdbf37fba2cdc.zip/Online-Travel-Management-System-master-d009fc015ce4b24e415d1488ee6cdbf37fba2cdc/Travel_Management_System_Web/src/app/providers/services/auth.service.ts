import { Injectable, InjectionToken, Optional, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { JwtHelperService } from '@auth0/angular-jwt';

export const TokenName: string = "jwt_Token";
export const API_IDENTITY_BASEURL = new InjectionToken<string>("API_IDENTITY_BASEURL");

@Injectable()
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);
  helper = new JwtHelperService();
  baseUrl;

  constructor(private http: HttpClient, @Optional() @Inject(API_IDENTITY_BASEURL) baseUrl?: string) {
    this.baseUrl = baseUrl ? baseUrl = "AuthService" : "http://localhost:63540/auth-api/AuthService";
    this.loggedIn.next(this.getToken() != null);
  }

  get isLoggedIn() {
    return this.loggedIn.asObservable();
  }

  getToken(): string {
    return localStorage.getItem(TokenName);
  }

  setToken(token: string): void {
    localStorage.setItem(TokenName, token);
  }

  getUserIdentity(): any {
    const jwtToken = this.getToken();
    let jwtData = jwtToken.split('.')[1];
    let decodedJwtJsonData = window.atob(jwtData);
    let decodedJwtData = JSON.parse(decodedJwtJsonData);
    return decodedJwtData;
  }

  isTokenExpired() {
    return this.helper.isTokenExpired(this.getToken());
  }

  getTokenExpirationDate() {
    return this.helper.getTokenExpirationDate(this.getToken());
  }

  deleteToken(): void {
    localStorage.removeItem(TokenName);
    this.loggedIn.next(false);
  }

  login(userDetails: any): Observable<any> {
    let url = `${this.baseUrl}` + "login";
    return this.http.post<any>(url, userDetails)
      .pipe(catchError(this.handleError('login')));
  }

  register(userData: IUser): Observable<any> {
    let url = `${this.baseUrl}` + "registration";
    return this.http.post<any>(url, userData)
      .pipe(catchError(this.handleError('register')));
  }

  getUserInfo(userDetails: any): Observable<any> {
    let url = `${this.baseUrl}` + "GetUserInfo?CustomerId=" + userDetails.customerId + "&EmployeeId=" + userDetails.employeeId;
    return this.http.get<any>(url)
      .pipe(catchError(this.handleError('getUserInfo')));
  }

  private handleError(operation: string) {
    return (error: any): Observable<any> => {
      console.error(error);
      let errMsg = (error.message) ? error.message :
        error.status ? `${error.status} - ${error.statusText}` : 'An server error occurred' + operation;
      let errObj = {
        title: errMsg,
        message: error.error
      };
      return throwError(errObj);
    };
  }
}