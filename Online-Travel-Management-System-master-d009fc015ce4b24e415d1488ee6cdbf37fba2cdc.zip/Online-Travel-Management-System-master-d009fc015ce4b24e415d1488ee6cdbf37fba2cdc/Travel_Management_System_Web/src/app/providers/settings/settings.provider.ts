import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class SettingsProvider {

    private config: any;

    private static readonly config_path = "./client-config.json";

    constructor(private http: HttpClient) { }

    get configuration(): any {
        return this.config;
    }

    get apiBaseUrl(): string {
        return this.config ? this.config.apiBaseUrl : "";
    }

    loadConfig(): Promise<any> {
        return new Promise<{}>((reslove, reject) => {
            this.http.get<any>(SettingsProvider.config_path).subscribe(
                settinng => {
                    this.config = Object.assign({}, settinng || {});
                    reslove(this.config);
                },
                error => {
                    this.config = {};
                    reslove(this.config);
                })
        });
    }
}