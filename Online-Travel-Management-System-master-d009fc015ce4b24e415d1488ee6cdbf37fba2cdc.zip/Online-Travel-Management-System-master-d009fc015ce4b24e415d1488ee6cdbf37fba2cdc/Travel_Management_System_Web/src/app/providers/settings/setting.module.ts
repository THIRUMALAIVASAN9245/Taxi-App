import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { SettingsProvider } from './settings.provider';

@NgModule({
    declarations: [],
    imports: [
        HttpClientModule
    ],
    providers: [
        SettingsProvider,
        {
            provide: APP_INITIALIZER,
            useFactory: init,
            deps: [SettingsProvider],
            multi: true
        }
    ]
})
export class SettingsModule { }

export function init(settingsProvider: SettingsProvider): any {
    return () => settingsProvider.loadConfig();
}