interface IUser {
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  dateOfBirth: string;
  gender: string;
  password: string;
  confirmPassword: string;
  roleId: string;
  status: string;
  vehicle: IVehicle;
}
class User implements IUser {
  public userId: string;
  public firstName: string;
  public lastName: string;
  public email: string;
  public phoneNumber: string;
  public dateOfBirth: string;
  public gender: string;
  public password: string;
  public confirmPassword: string;
  public roleId: string;
  public status: string;
  public vehicle: IVehicle;

  constructor(userId: string, firstName: string, lastName: string, email: string, phoneNumber: string,
    dateOfBirth: string, gender: string, password: string, confirmPassword: string, roleId: string, status: string, vehicle: IVehicle) {
    this.userId = userId;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.password = password;
    this.confirmPassword = confirmPassword;
    this.dateOfBirth = dateOfBirth;
    this.gender = gender;
    this.roleId = roleId;
    this.status = status;
    this.vehicle = vehicle;
  }
}