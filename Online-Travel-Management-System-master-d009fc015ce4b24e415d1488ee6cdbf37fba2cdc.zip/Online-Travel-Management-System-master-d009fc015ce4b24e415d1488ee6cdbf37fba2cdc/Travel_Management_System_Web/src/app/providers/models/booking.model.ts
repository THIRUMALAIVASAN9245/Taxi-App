interface IBooking {
  id: string;
  bookingId: string;
  pickupLocation: string;
  pickupDate: string;
  pickupTime: string;
  dropLocation: string;
  amount: string;
}
class Booking implements IBooking {
  public id: string;
  public bookingId: string;
  public pickupLocation: string;
  public pickupDate: string;
  public pickupTime: string;
  public dropLocation: string;
  public amount: string;

  constructor(id: string, bookingId: string, pickupLocation: string, pickupDate: string, pickupTime: string, dropLocation: string, amount: string) {
    this.id = id;
    this.bookingId = bookingId;
    this.pickupLocation = pickupLocation;
    this.pickupDate = pickupDate;
    this.pickupTime = pickupTime;
    this.dropLocation = dropLocation;
    this.amount = amount;
  }
}