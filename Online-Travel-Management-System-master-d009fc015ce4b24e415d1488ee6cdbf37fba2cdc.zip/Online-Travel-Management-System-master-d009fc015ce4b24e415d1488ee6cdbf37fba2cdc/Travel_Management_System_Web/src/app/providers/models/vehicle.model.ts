interface IVehicle {
    vehicleNumber: string;
    licenseNumber: string;
    insurance: string;
    permit: string;
    registration: string;
    description: string;
}
class Vehicle implements IVehicle {
    public vehicleNumber: string;
    public licenseNumber: string;
    public insurance: string;
    public permit: string;
    public registration: string;
    public description: string;

    constructor(vehicleNumber: string, licenseNumber: string, insurance: string, permit: string, registration: string, description: string) {
        this.vehicleNumber = vehicleNumber;
        this.licenseNumber = licenseNumber;
        this.insurance = insurance;
        this.permit = permit;
        this.registration = registration;
        this.description = description;
    }
}