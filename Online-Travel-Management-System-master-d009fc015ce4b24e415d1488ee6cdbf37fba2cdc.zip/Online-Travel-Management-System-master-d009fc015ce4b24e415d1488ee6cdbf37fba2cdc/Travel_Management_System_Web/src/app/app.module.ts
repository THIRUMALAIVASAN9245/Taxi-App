import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BsDatepickerModule, TimepickerModule, ModalModule, PaginationModule } from 'ngx-bootstrap';

import { AppRouting } from './app.routing';
import { AppComponent } from './app.component';

import { AuthenticationModule } from './authentication/authentication.module';
import { bookingModule } from './booking/booking.module';

import { AuthService, API_IDENTITY_BASEURL } from './providers/services/auth.service';
import { AuthGuard } from './providers/services/auth-guard.service';
import { UiSwitchModule } from 'ngx-ui-switch';
import { SettingsProvider } from './providers/settings/settings.provider';
import { API_BOOKING_BASEURL } from './providers/services/booking.service';
import { SettingsModule } from './providers/settings/setting.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    Ng4LoadingSpinnerModule.forRoot(),
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    PaginationModule.forRoot(),
    TimepickerModule.forRoot(),
    UiSwitchModule,
    ModalModule.forRoot(),
    AuthenticationModule,
    bookingModule,
    SettingsModule,
    AppRouting
  ],
  providers: [
    AuthGuard,
    AuthService,
    {
      provide: API_IDENTITY_BASEURL,
      useFactory: baseUrlFactory,
      deps: [SettingsProvider],
      multi: false
    },
    {
      provide: API_BOOKING_BASEURL,
      useFactory: bookingBaseUrlFactory,
      deps: [SettingsProvider],
      multi: false
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function baseUrlFactory(settingsProvider: SettingsProvider): string {
  return settingsProvider.configuration.apiIdentityBaseUrl;
}

export function bookingBaseUrlFactory(settingsProvider: SettingsProvider): string {
  return settingsProvider.configuration.apiBookingBaseUrl;
}