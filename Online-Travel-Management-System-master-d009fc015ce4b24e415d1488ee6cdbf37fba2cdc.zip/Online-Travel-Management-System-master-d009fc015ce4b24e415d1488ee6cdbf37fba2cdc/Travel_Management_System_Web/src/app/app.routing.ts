import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const appRoutes: Routes = [
  { path: '', redirectTo: '/auth/login', pathMatch: 'full' },
  { path: "**", redirectTo: '/auth/login' }
];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(appRoutes);