import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { bookingComponent } from './booking.component';

describe('booking Component Scenarios: ', () => {
    let fixture: ComponentFixture<bookingComponent>;
    let component: bookingComponent;

    beforeEach(async(() => {
        // arrange
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [bookingComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: []
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(bookingComponent)
        component = fixture.componentInstance;
    });

    describe("bookingComponent", () => {
        it("should create the booking component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });
});