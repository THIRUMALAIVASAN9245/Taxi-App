import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import * as moment from 'moment';

import { BookingService } from '../../providers/services/booking.service';

@Component({
  selector: 'app-create-booking',
  templateUrl: './create-booking.component.html'
})
export class CreateRideComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  isErrorMessage: string = "";
  modalRef: BsModalRef | null;
  modalRef2: BsModalRef;
  config = {
    backdrop: true,
    ignoreBackdropClick: true,
    class: 'modal-sm'
  };
  constructor(private router: Router,
    private modalService: BsModalService,
    private spinnerService: Ng4LoadingSpinnerService,
    private formBuilder: FormBuilder,
    private bookingService: BookingService) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      pickupLocation: ['', [Validators.required]],
      dropLocation: ['', [Validators.required]],
      pickupDate: ['', [Validators.required]],
      pickupTime: ['', [Validators.required]],
      status: ['Pending', []],
      amount: ['', []]
    });
  }

  openModal(template: TemplateRef<any>) {
    this.isErrorMessage = "";
    this.submitted = true;

    if (this.registerForm.invalid) {
      return;
    }

    this.isErrorMessage = "";
    this.config.class = "modal-sm modal-dialog-centered";
    this.modalRef = this.modalService.show(template, this.config);
  }

  openModal2(template: TemplateRef<any>) {
    this.config.class = "second modal-dialog-centered";
    this.isErrorMessage = "";
    this.spinnerService.show();
    const registerData = this.registerForm.value;
    const pickupTime = moment(registerData["pickupTime"]).format("hh:mm A");
    registerData["pickupTime"] = pickupTime;
    const response = this.bookingService.booking(registerData);
    response.subscribe((response) => {
      this.spinnerService.hide();
      this.modalRef2 = this.modalService.show(template, this.config);
    }, error => {
      this.spinnerService.hide();
      this.isErrorMessage = error.message;
    });
  }

  back() {
    this.router.navigate(['/booking/booking-details'])
  }

  closeFirstModal() {
    this.isErrorMessage = "";
    if (!this.modalRef) {
      this.router.navigate(['/booking/booking-details']);
      return;
    }

    this.modalRef.hide();
    this.modalRef = null;
  }

  closeFirstModalNavigate() {
    this.router.navigate(['/booking/booking-details']);
    this.modalRef2.hide();
    this.modalRef.hide();
  }

  get f() { return this.registerForm.controls; }
}