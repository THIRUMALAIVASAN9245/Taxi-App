import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of, throwError } from 'rxjs';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { CreateRideComponent } from './create-booking.component';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { BookingService } from 'src/app/providers/services/booking.service';
import { Router } from '@angular/router';

describe('RideDetails Component Positive Scenarios: ', () => {
    let fixture: ComponentFixture<CreateRideComponent>;
    let component: CreateRideComponent;
    let mockBsModalService: BsModalService;
    let mockBookingService: BookingService;
    let mockNg4LoadingSpinnerService: Ng4LoadingSpinnerService;
    let mockRouter: Router;
    let mockFormBuilder: FormBuilder;

    beforeEach(async(() => {
        // arrange
        mockRouter = jasmine.createSpyObj("router", ["navigate"]);
        mockBsModalService = jasmine.createSpyObj("BsModalService", ["show", "hide"]);
        mockNg4LoadingSpinnerService = jasmine.createSpyObj("mockNg4LoadingSpinnerService", ["show", "hide"]);

        mockBookingService = jasmine.createSpyObj("BookingService", ["updateBooking", "getBookings", "booking"]);
        ((mockBookingService.updateBooking) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));
        ((mockBookingService.getBookings) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));
        ((mockBookingService.booking) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [CreateRideComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: Router, useValue: mockRouter },
                { provide: BookingService, useValue: mockBookingService },
                { provide: BsModalService, useValue: mockBsModalService },
                { provide: Ng4LoadingSpinnerService, useValue: mockNg4LoadingSpinnerService },
                FormBuilder]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(CreateRideComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the CreateRide component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("back and closeFirstModalNavigate", () => {
        it("should call back", () => {
            // act
            component.back();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalled();
        });

        it("should call closeFirstModalNavigate", () => {
            // Arrange
            spyOn(console, "log");
            component.modalRef = {
                hide: function () {
                    console.log("test");
                },
                setClass: null
            };
            component.modalRef2 = {
                hide: function () {
                    console.log("test");
                },
                setClass: null
            };

            // act
            component.closeFirstModalNavigate();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalled();
        });
    });

    describe("closeFirstModal", () => {
        it("should call closeFirstModal and modalRef null", () => {
            // Arrange
            spyOn(console, "log");
            component.modalRef = {
                hide: function () {
                    console.log("test");
                },
                setClass: null,
                content: "testContent"
            };

            // act
            component.closeFirstModal();

            // assert           
            expect(mockRouter.navigate).not.toHaveBeenCalled();
        });

        it("should call closeFirstModal and with modalRef", () => {
            // Arrange
            component.modalRef = null;

            // act
            component.closeFirstModal();

            // assert           
            expect(mockRouter.navigate).toHaveBeenCalled();
        });
    });

    describe("openModal", () => {
        it("should registerForm invalid", () => {
            // Arrange
            component.ngOnInit();

            // act
            component.openModal(null);

            // assert
            expect(component.registerForm.invalid).toBeTruthy();
        });

        it("should registerForm invalid", () => {
            // arrange
            component.ngOnInit();
            const testUser = {
                pickupLocation: 'chennai',
                dropLocation: 'bangalore',
                pickupDate: "12-12-2019",
                pickupTime: '12:30 AM'
            };

            Object.keys(testUser).forEach(name => {
                if (component.registerForm.controls[name]) {
                    component.registerForm.controls[name].patchValue(testUser[name]);
                }
            });

            // act
            component.openModal(null);

            // assert
            expect(mockBsModalService.show).toHaveBeenCalled();
        });
    });

    describe("openModal2", () => {
        it("should openModal2 show model", () => {
            // arrange
            component.ngOnInit();
            const testUser = {
                pickupLocation: 'chennai',
                dropLocation: 'bangalore',
                pickupDate: "12-12-2019",
                pickupTime: new Date()
            };

            Object.keys(testUser).forEach(name => {
                if (component.registerForm.controls[name]) {
                    component.registerForm.controls[name].patchValue(testUser[name]);
                }
            });

            // act
            component.openModal2(null);

            // assert
            expect(mockBookingService.booking).toHaveBeenCalled();
        });
    });
});