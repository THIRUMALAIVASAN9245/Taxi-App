import { Component } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html'
})
export class BookingDetailsComponent {
  customerInfo: IUser;
  employeeInfo: IUser;
  bookingInfo: IBooking;

  constructor(public bsModalRef: BsModalRef) { }

}