import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap';

import { BookingDetailsComponent } from './view-booking.component';

describe('Header Component Scenarios: ', () => {
    let fixture: ComponentFixture<BookingDetailsComponent>;
    let component: BookingDetailsComponent;
    let mockBsModalRef: BsModalRef;

    beforeEach(async(() => {
        // arrange
        mockBsModalRef = jasmine.createSpyObj("mockBsModalRef", ["navigate"]);
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [BookingDetailsComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: BsModalRef, useValue: mockBsModalRef }]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(BookingDetailsComponent)
        component = fixture.componentInstance;
    });

    describe("ngOnInit Method", () => {
        it("should create the BookingDetails component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });
});