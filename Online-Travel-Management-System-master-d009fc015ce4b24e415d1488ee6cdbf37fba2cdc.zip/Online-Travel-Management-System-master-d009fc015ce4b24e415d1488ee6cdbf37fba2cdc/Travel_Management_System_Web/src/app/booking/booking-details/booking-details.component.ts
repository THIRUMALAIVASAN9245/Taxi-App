import { Component, OnInit } from '@angular/core';
import { BookingService } from '../../providers/services/booking.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AuthService } from 'src/app/providers/services/auth.service';
import { BsModalRef, BsModalService, PageChangedEvent } from 'ngx-bootstrap';
import { BookingDetailsComponent } from './view-booking/view-booking.component';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html'
})
export class RideDetailsComponent implements OnInit {
  rideDetails: IBooking[];
  userRoleId: string;
  isErrorMessage: string = "";
  bsModalRef: BsModalRef;
  currentPage: number = 1;
  totalItems: number;

  constructor(
    private modalService: BsModalService,
    private spinnerService: Ng4LoadingSpinnerService,
    private bookingService: BookingService,
    private authService: AuthService) { }

  ngOnInit(): void {
    this.getUserRoleId();
    this.getBookingDetails();
  }

  pageChanged(event: PageChangedEvent): void {
    this.currentPage = event.page;
    this.getBookingDetails();
  }

  updateBooking(bookingDetail: any, status: string): void {
    if (status === "Accepted") {
      bookingDetail.employeeId = this.getUserId();
    }
    bookingDetail.status = status;
    this.isErrorMessage = "";
    this.spinnerService.show();
    const response = this.bookingService.updateBooking(bookingDetail);
    response.subscribe((response) => {
      this.spinnerService.hide();
      this.getBookingDetails();
    }, error => {
      this.spinnerService.hide();
      this.isErrorMessage = error.message;
    });
  }

  viewBooking(bookingDetail: any): void {
    this.isErrorMessage = "";
    this.spinnerService.show();
    const response = this.authService.getUserInfo(bookingDetail);
    response.subscribe((response) => {
      this.spinnerService.hide();
      const initialState = {
        bookingInfo: bookingDetail,
        customerInfo: response && response.customer,
        employeeInfo: response && response.employee
      };
      this.bsModalRef = this.modalService.show(BookingDetailsComponent, {
        initialState,
        ignoreBackdropClick: true,
        class: 'modal-lg modal-dialog-centered'
      });
    }, error => {
      this.spinnerService.hide();
      this.isErrorMessage = error.message;
    });
  }

  private getUserRoleId() {
    this.userRoleId = this.authService.getUserIdentity().roleId;
  }

  private getUserId() {
    return this.authService.getUserIdentity().userId;
  }

  private getBookingDetails() {
    this.isErrorMessage = "";
    this.spinnerService.show();
    const response = this.bookingService.getBookings(this.currentPage);
    response.subscribe((response) => {
      this.spinnerService.hide();
      this.totalItems = response.count;
      this.rideDetails = response.bookingDetails;
    }, error => {
      this.spinnerService.hide();
      this.isErrorMessage = error.message;
    });
  }
}