import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { of, throwError } from 'rxjs';

import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AuthService } from 'src/app/providers/services/auth.service';

import { RideDetailsComponent } from './booking-details.component';
import { BsModalService, PageChangedEvent } from 'ngx-bootstrap';
import { BookingService } from 'src/app/providers/services/booking.service';

describe('RideDetails Component Positive Scenarios: ', () => {
    let fixture: ComponentFixture<RideDetailsComponent>;
    let component: RideDetailsComponent;
    let mockBsModalService: BsModalService;
    let mockBookingService: BookingService;
    let mockNg4LoadingSpinnerService: Ng4LoadingSpinnerService;
    let mockAuthService: AuthService;

    beforeEach(async(() => {
        // arrange
        mockBsModalService = jasmine.createSpyObj("BsModalService", ["show"]);
        mockNg4LoadingSpinnerService = jasmine.createSpyObj("mockNg4LoadingSpinnerService", ["show", "hide"]);
        mockAuthService = jasmine.createSpyObj("AuthService", ["getUserInfo", "getUserIdentity"]);
        ((mockAuthService.getUserIdentity) as jasmine.Spy).and.returnValue({ "roleId": "2", "userId": "123456" });
        ((mockAuthService.getUserInfo) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));

        mockBookingService = jasmine.createSpyObj("BookingService", ["updateBooking", "getBookings"]);
        ((mockBookingService.updateBooking) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));
        ((mockBookingService.getBookings) as jasmine.Spy).and.returnValue(of('{ "token": "qwerpoiuytr"}'));

        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [RideDetailsComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: [
                { provide: BookingService, useValue: mockBookingService },
                { provide: AuthService, useValue: mockAuthService },
                { provide: BsModalService, useValue: mockBsModalService },
                { provide: Ng4LoadingSpinnerService, useValue: mockNg4LoadingSpinnerService }
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(RideDetailsComponent)
        component = fixture.componentInstance;
    });

    describe("RideDetailsComponent", () => {
        it("should create the RideDetails component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });

    describe("ngOnInit", () => {
        beforeEach(() => {
            // act                                     
            component.ngOnInit();
        });

        it("should verify userRoleId", () => {
            // assert           
            expect(component.userRoleId).toEqual("2");
        });
    });

    describe("updateBooking", () => {
        it("should verify updateBooking method", () => {
            // arrange   
            const bookingDetail = {
                bookingid: "book1767",
                pickupaddress: "tadwadi, surat, gujarat, india",
                pickupdate: new Date("1990-02-02"),
                dropaddress: "delhi, india",
                dropdate: new Date("1990-02-02"),
                employeeId: "",
                amount: "743",
                paymentstatus: "",
                status: "Pending"
            };

            // act
            component.updateBooking(bookingDetail, "Accepted");

            // assert           
            expect(mockBookingService.getBookings).toHaveBeenCalled();
        });
    });

    describe("pageChanged", () => {
        it("should verify pageChanged method", () => {
            // arrange   
            const bookingDetail = {
                page: 10
            };

            // act
            component.pageChanged(bookingDetail as PageChangedEvent);

            // assert         
            expect(component.currentPage).toBe(10);
            expect(mockBookingService.getBookings).toHaveBeenCalled();
        });
    });

    describe("viewBooking", () => {
        it("should verify viewBooking method", () => {
            // arrange   
            const bookingDetail = {
                bookingid: "book1767",
                pickupaddress: "tadwadi, surat, gujarat, india",
                pickupdate: new Date("1990-02-02"),
                dropaddress: "delhi, india",
                dropdate: new Date("1990-02-02"),
                employeeId: "",
                amount: "743",
                paymentstatus: "",
                status: "Pending"
            };

            // act
            component.viewBooking(bookingDetail);

            // assert           
            expect(mockAuthService.getUserInfo).toHaveBeenCalled();
            expect(mockBsModalService.show).toHaveBeenCalled();
        });
    });
});
