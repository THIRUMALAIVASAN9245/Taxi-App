import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { bookingComponent } from './booking.component';
import { AuthGuard } from '../providers/services/auth-guard.service';
import { RideDetailsComponent } from './booking-details/booking-details.component';
import { CreateRideComponent } from './create-booking/create-booking.component';

const bookingRoutes: Routes = [
  {
    path: 'booking',
    component: bookingComponent,
    children: [
      { path: '', redirectTo: '/booking-details', pathMatch: 'full', canActivate: [AuthGuard] },
      { path: "booking-details", component: RideDetailsComponent, canActivate: [AuthGuard] },
      { path: "create-ride", component: CreateRideComponent, canActivate: [AuthGuard] }
    ]
  }];

export const bookingRouting: ModuleWithProviders = RouterModule.forRoot(bookingRoutes);