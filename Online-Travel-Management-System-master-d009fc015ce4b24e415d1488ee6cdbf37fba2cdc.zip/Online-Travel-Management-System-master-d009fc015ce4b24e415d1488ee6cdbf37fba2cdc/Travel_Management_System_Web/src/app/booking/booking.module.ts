import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { BsDatepickerModule, TimepickerModule, ModalModule, PaginationModule } from 'ngx-bootstrap';

import { bookingRouting } from './booking.routing';
import { bookingComponent } from './booking.component';

import { HeaderComponent } from '../common/header/header.component';
import { FooterComponent } from '../common/footer/footer.component';

import { AuthInterceptor } from '../providers/services/auth.Interceptor';
import { BookingService } from '../providers/services/booking.service';
import { RideDetailsComponent } from './booking-details/booking-details.component';
import { CreateRideComponent } from './create-booking/create-booking.component';
import { BookingDetailsComponent } from './booking-details/view-booking/view-booking.component';

@NgModule({
  declarations: [
    bookingComponent,
    HeaderComponent,
    FooterComponent,
    RideDetailsComponent,
    CreateRideComponent,
    BookingDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    Ng4LoadingSpinnerModule.forRoot(),
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    PaginationModule.forRoot(),
    TimepickerModule.forRoot(),
    ModalModule.forRoot(),
    bookingRouting
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    BookingService
  ],
  entryComponents: [
    BookingDetailsComponent
  ]
})
export class bookingModule { }
