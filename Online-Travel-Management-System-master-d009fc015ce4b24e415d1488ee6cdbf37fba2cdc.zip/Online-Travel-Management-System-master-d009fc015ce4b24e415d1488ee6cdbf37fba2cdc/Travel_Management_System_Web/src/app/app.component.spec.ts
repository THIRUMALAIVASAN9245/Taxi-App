import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { AppComponent } from './app.component';

describe('App Component Scenarios: ', () => {
    let fixture: ComponentFixture<AppComponent>;
    let component: AppComponent;

    beforeEach(async(() => {
        // arrange
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [AppComponent],
            schemas: [NO_ERRORS_SCHEMA],
            providers: []
        }).compileComponents();
    }));

    beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(AppComponent)
        component = fixture.componentInstance;
    });

    describe("AppComponent", () => {
        it("should create the App component", () => {
            // assert
            expect(component).toBeTruthy();
        });
    });
});