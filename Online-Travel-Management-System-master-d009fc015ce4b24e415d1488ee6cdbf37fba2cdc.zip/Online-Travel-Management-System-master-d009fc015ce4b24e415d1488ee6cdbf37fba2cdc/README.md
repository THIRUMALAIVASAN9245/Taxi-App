<div align="center" style="padding-left: 44%;">
  <a href="https://getbootstrap.com/">
    <img src="https://code.cognizant.com/568182/Online-Travel-Management-System/raw/master/Travel_Management_System_Web/src/assets/taxi_logo.png" alt="Bootstrap logo" width="72" height="72">
  </a>
</div>

<div align="center" style="padding-left: 30%;"><b>Online Travel Management System</b></div>


## Table of contents

- [Architecture Online Travel Management System](#Architecture-Online-Travel-Management-System)
- [Domain Driven Design Microservice](#Domain-Driven-Design-Microservice)


## Architecture Online Travel Management System

<div align="center">
 <img src="https://code.cognizant.com/568182/Online-Travel-Management-System/raw/master/Document/Architecture-Online-Travel-Management-System.png" alt="Architecture Diagram" width="80%" height="100%">
</div>


## Domain Driven Design Microservice

<div align="center">
 <img src="https://code.cognizant.com/568182/Online-Travel-Management-System/raw/master/Document/Domain-Driven-Design-Microservice.png" alt="Domain-Driven-Design Pattern" width="80%" height="100%">
</div>
